@echo off
if exist "%GRADLE_HOME%\bin\gradle.bat" (
  set GRADLE_CMD=%GRADLE_HOME%\bin\gradle.bat
) else (
  where gradle >nul 2>&1
  if %ERRORLEVEL%==0 (
    set GRADLE_CMD=gradle
  ) else (
    echo ERROR: Gradle not found. Run install.bat first.
    pause
    exit /b 1
  )
)
%GRADLE_CMD% %*
