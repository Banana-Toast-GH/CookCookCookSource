package com.cookcookcook.desktop;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import com.cookcookcook.CookCookCookGame;

public class DesktopLauncher {
    public static void main(String[] args) {
        Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
        config.setForegroundFPS(60);
        config.setTitle("Cook, Cook, Cook!");
        config.setWindowedMode(1280, 720);
        config.setWindowIcon("textures/icon.png");
        config.useVsync(true);
        new Lwjgl3Application(new CookCookCookGame(), config);
    }
}
