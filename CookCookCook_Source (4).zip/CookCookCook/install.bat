@echo off
setlocal enabledelayedexpansion
title Cook, Cook, Cook! - Installer
color 0A

echo.
echo  ====================================================
echo    COOK, COOK, COOK! - Installer ^& Builder
echo    Becoming God takes a few minutes. Please wait.
echo  ====================================================
echo.

:: ============================================================
:: STEP 1: Check Java
:: ============================================================
echo [1/5] Checking Java installation...
java -version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo  Java not found. Downloading Java 21...
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; (New-Object System.Net.WebClient).DownloadFile('https://download.java.net/java/GA/jdk21.0.2/f2283984656d49d69e91c558476027ac/13/GPL/openjdk-21.0.2_windows-x64_bin.zip','%TEMP%\jdk21.zip')"
    powershell -Command "Expand-Archive -Path '%TEMP%\jdk21.zip' -DestinationPath 'C:\jdk21' -Force"
    set "JAVA_HOME=C:\jdk21\jdk-21.0.2"
    set "PATH=C:\jdk21\jdk-21.0.2\bin;%PATH%"
    setx JAVA_HOME "C:\jdk21\jdk-21.0.2" /M >nul 2>&1
    echo  Java 21 installed!
) else (
    echo  Java found!
)

:: ============================================================
:: STEP 2: Get Gradle
:: ============================================================
echo [2/5] Checking Gradle installation...

:: First check if already installed at our known location
if exist "C:\gradle\gradle-8.4\bin\gradle.bat" (
    set "GRADLE_EXE=C:\gradle\gradle-8.4\bin\gradle.bat"
    echo  Gradle found at C:\gradle\gradle-8.4
    goto gradle_ok
)

:: Check if on PATH
where gradle >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set "GRADLE_EXE=gradle"
    echo  Gradle found on PATH!
    goto gradle_ok
)

:: Need to download
echo  Gradle not found. Downloading...
powershell -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; (New-Object System.Net.WebClient).DownloadFile('https://services.gradle.org/distributions/gradle-8.4-bin.zip','%TEMP%\gradle.zip')"

if not exist "%TEMP%\gradle.zip" (
    curl -L --ssl-no-revoke -o "%TEMP%\gradle.zip" "https://services.gradle.org/distributions/gradle-8.4-bin.zip" 2>nul
)

if not exist "%TEMP%\gradle.zip" (
    echo.
    echo  [ERROR] Could not download Gradle.
    echo  Manual install: https://gradle.org/releases/
    echo  Download gradle-8.4-bin.zip, extract to C:\gradle\gradle-8.4
    pause
    exit /b 1
)

echo  Extracting Gradle...
powershell -Command "Expand-Archive -Path '%TEMP%\gradle.zip' -DestinationPath 'C:\gradle' -Force"
set "GRADLE_EXE=C:\gradle\gradle-8.4\bin\gradle.bat"
setx GRADLE_HOME "C:\gradle\gradle-8.4" /M >nul 2>&1
echo  Gradle installed!

:gradle_ok

:: ============================================================
:: STEP 3: Locate source
:: ============================================================
echo [3/5] Locating game source...
cd /d "%~dp0"
if not exist "build.gradle" (
    echo  [ERROR] build.gradle not found. Run install.bat from inside the CookCookCook folder.
    pause
    exit /b 1
)
echo  Source folder: %CD%

:: ============================================================
:: STEP 4: Build
:: ============================================================
echo [4/5] Building Cook, Cook, Cook!
echo  First run downloads ~50MB of LibGDX. Takes 2-5 minutes.
echo.

echo  Using Gradle: !GRADLE_EXE!
"!GRADLE_EXE!" desktop:jar --no-daemon

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo  [ERROR] Build failed! See errors above.
    echo  Common fixes:
    echo    - Internet connection required on first build
    echo    - Run as Administrator
    echo    - java -version should show 11 or higher
    pause
    exit /b 1
)
echo  Build successful!

:: ============================================================
:: STEP 5: Shortcuts
:: ============================================================
echo [5/5] Creating shortcuts...

(
    echo @echo off
    echo cd /d "%~dp0"
    echo java -jar desktop\build\libs\CookCookCook.jar
    echo if %%ERRORLEVEL%% NEQ 0 pause
) > "%~dp0Launch_CookCookCook.bat"

set "LINK=%USERPROFILE%\Desktop\Cook Cook Cook!.lnk"
set "TGT=%~dp0Launch_CookCookCook.bat"
set "WD=%~dp0"
powershell -Command "$ws=New-Object -ComObject WScript.Shell;$s=$ws.CreateShortcut('!LINK!');$s.TargetPath='!TGT!';$s.WorkingDirectory='!WD!';$s.Description='Cook Cook Cook!';$s.Save()" >nul 2>&1

if exist "!LINK!" (echo  Desktop shortcut created!) else (echo  Use Launch_CookCookCook.bat to play.)

:: ============================================================
:: DONE
:: ============================================================
echo.
echo  ====================================================
echo    DONE! You are ready to cook.
echo.
echo    CONTROLS:
echo      WASD         - Move
echo      Right-Click  - Look around
echo      E            - Interact
echo      SPACE        - Minigame (chop / cool)
echo      ESC          - Close menus
echo  ====================================================
echo.
set /p "GO=Launch the game now? (Y/N): "
if /i "!GO!"=="Y" start "" "%~dp0Launch_CookCookCook.bat"
pause
