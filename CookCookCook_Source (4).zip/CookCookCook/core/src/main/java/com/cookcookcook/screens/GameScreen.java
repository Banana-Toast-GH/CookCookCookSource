package com.cookcookcook.screens;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.g3d.*;
import com.badlogic.gdx.graphics.g3d.attributes.*;
import com.badlogic.gdx.graphics.g3d.environment.*;
import com.badlogic.gdx.graphics.g3d.utils.*;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.utils.*;
import com.cookcookcook.CookCookCookGame;
import com.cookcookcook.systems.*;
import com.cookcookcook.ui.*;
import com.cookcookcook.world.*;

public class GameScreen implements Screen {

    private final CookCookCookGame game;

    // 3D
    private PerspectiveCamera camera;
    private ModelBatch modelBatch;
    private Environment environment;
    private Array<ModelInstance> worldInstances;
    private WorldBuilder worldBuilder;

    // 2D overlay
    private SpriteBatch uiBatch;
    private BitmapFont font;
    private BitmapFont bigFont;

    // Systems
    private PlayerController playerController;
    private CustomerSystem customerSystem;
    private CookingStation cookingStation;
    private ShopSystem shopSystem;
    private StockBoard stockBoard;
    private Newspaper newspaper;
    private HUD hud;

    // State
    public enum GameState {
        EXPLORING, SHOPPING, COOKING, READING_NEWSPAPER, VIEWING_STOCKS, MINIGAME_KNIFE, MINIGAME_BOIL, ASCENSION
    }
    private GameState state = GameState.EXPLORING;
    private float dayTimer = 0f;
    private float dayLength = 180f; // 3 minutes per day

    // Interaction
    private String interactionPrompt = "";
    private float interactionRange = 3f;

    public GameScreen(CookCookCookGame game) {
        this.game = game;
    }

    @Override
    public void show() {
        // Camera
        camera = new PerspectiveCamera(67f, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.position.set(0f, 3f, 8f);
        camera.lookAt(0f, 1f, 0f);
        camera.near = 0.1f;
        camera.far = 300f;
        camera.update();

        // Rendering
        modelBatch = CookCookCookGame.modelBatch;
        environment = CookCookCookGame.environment;

        // Build world
        worldBuilder = new WorldBuilder();
        worldInstances = worldBuilder.buildWorld();

        // UI
        uiBatch = new SpriteBatch();
        font = new BitmapFont();
        font.getData().setScale(1.2f);
        bigFont = new BitmapFont();
        bigFont.getData().setScale(2f);

        // Systems
        playerController = new PlayerController(camera);
        customerSystem = new CustomerSystem();
        cookingStation = new CookingStation();
        shopSystem = new ShopSystem();
        stockBoard = new StockBoard();
        newspaper = new Newspaper();
        hud = new HUD(font, bigFont);

        Gdx.input.setInputProcessor(playerController);
    }

    @Override
    public void render(float delta) {
        // Update
        update(delta);

        // Clear
        Gdx.gl.glViewport(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        Gdx.gl.glClearColor(0.52f, 0.75f, 0.92f, 1f); // sky blue

        // 3D render
        modelBatch.begin(camera);
        for (ModelInstance inst : worldInstances) {
            modelBatch.render(inst, environment);
        }
        customerSystem.render(modelBatch, environment);
        modelBatch.end();

        // 2D HUD overlay
        uiBatch.begin();
        renderHUD();
        renderStateUI();
        uiBatch.end();
    }

    private void update(float delta) {
        dayTimer += delta;

        switch (state) {
            case EXPLORING:
                playerController.update(delta);
                camera.update();
                customerSystem.update(delta);
                checkInteractions();
                handleExploreInput();
                // End of day
                if (dayTimer >= dayLength) {
                    endDay();
                }
                // Greed escalation
                if (CookCookCookGame.greedLevel >= 100f) {
                    triggerAscension();
                }
                break;
            case COOKING:
                cookingStation.update(delta);
                if (cookingStation.isComplete()) {
                    finishCooking();
                }
                break;
            case SHOPPING:
                shopSystem.update(delta);
                if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
                    state = GameState.EXPLORING;
                    Gdx.input.setInputProcessor(playerController);
                }
                break;
            case MINIGAME_KNIFE:
            case MINIGAME_BOIL:
                cookingStation.updateMinigame(delta);
                if (cookingStation.isMinigameComplete()) {
                    state = GameState.COOKING;
                }
                break;
            case READING_NEWSPAPER:
                if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
                    state = GameState.EXPLORING;
                }
                break;
            case VIEWING_STOCKS:
                stockBoard.update(delta);
                if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
                    state = GameState.EXPLORING;
                }
                break;
            case ASCENSION:
                // Handled by ascension screen
                break;
        }
    }

    private void checkInteractions() {
        interactionPrompt = "";
        Vector3 pos = camera.position;

        // Check shop (across the street at z = -15)
        if (pos.dst(new Vector3(0, 1.5f, -12f)) < interactionRange) {
            interactionPrompt = "[E] Enter Shop";
            if (Gdx.input.isKeyJustPressed(Input.Keys.E)) {
                state = GameState.SHOPPING;
                shopSystem.open();
            }
        }
        // Cooking station
        else if (pos.dst(new Vector3(-2f, 1.5f, 2f)) < interactionRange) {
            interactionPrompt = "[E] Use Cooking Station";
            if (Gdx.input.isKeyJustPressed(Input.Keys.E)) {
                if (shopSystem.getInventory().size > 0) {
                    state = GameState.COOKING;
                    cookingStation.startCooking(shopSystem.getInventory());
                } else {
                    interactionPrompt = "No ingredients! Visit the shop first.";
                }
            }
        }
        // Newspaper outside
        else if (pos.dst(new Vector3(5f, 1.5f, 6f)) < interactionRange) {
            interactionPrompt = "[E] Read Newspaper";
            if (Gdx.input.isKeyJustPressed(Input.Keys.E)) {
                state = GameState.READING_NEWSPAPER;
                newspaper.generateHeadline();
            }
        }
        // Stock board inside truck
        else if (pos.dst(new Vector3(2f, 1.5f, 3f)) < interactionRange) {
            interactionPrompt = "[E] Check Stocks";
            if (Gdx.input.isKeyJustPressed(Input.Keys.E)) {
                state = GameState.VIEWING_STOCKS;
            }
        }
        // Customer window
        else if (pos.dst(new Vector3(0f, 1.5f, 0f)) < interactionRange && customerSystem.hasWaitingCustomer()) {
            interactionPrompt = "[E] Serve Customer";
            if (Gdx.input.isKeyJustPressed(Input.Keys.E)) {
                serveCustomer();
            }
        }
    }

    private void handleExploreInput() {
        // Quick knife minigame test
        if (Gdx.input.isKeyJustPressed(Input.Keys.K)) {
            cookingStation.startKnifeMinigame();
            state = GameState.MINIGAME_KNIFE;
        }
    }

    private void serveCustomer() {
        if (cookingStation.hasReadyFood()) {
            float tip = customerSystem.serveCurrentCustomer(cookingStation.getReadyFood());
            CookCookCookGame.money += tip;
            CookCookCookGame.totalCustomersServed++;
            CookCookCookGame.greedLevel = Math.min(100f, CookCookCookGame.greedLevel + 2f);
            cookingStation.consumeFood();
        } else {
            interactionPrompt = "You have no food ready!";
        }
    }

    private void finishCooking() {
        state = GameState.EXPLORING;
        Gdx.input.setInputProcessor(playerController);
    }

    private void endDay() {
        dayTimer = 0f;
        CookCookCookGame.day++;
        stockBoard.simulateMarket();
        customerSystem.reset();
        newspaper.updateReputation();
    }

    private void triggerAscension() {
        game.setScreen(new AscensionScreen(game));
        dispose();
    }

    private void renderHUD() {
        hud.render(uiBatch, state, interactionPrompt, dayTimer, dayLength);
    }

    private void renderStateUI() {
        switch (state) {
            case SHOPPING:
                shopSystem.renderUI(uiBatch, font, bigFont);
                break;
            case COOKING:
                cookingStation.renderUI(uiBatch, font, bigFont);
                break;
            case MINIGAME_KNIFE:
            case MINIGAME_BOIL:
                cookingStation.renderMinigameUI(uiBatch, font, bigFont);
                break;
            case READING_NEWSPAPER:
                newspaper.renderUI(uiBatch, font, bigFont);
                break;
            case VIEWING_STOCKS:
                stockBoard.renderUI(uiBatch, font, bigFont);
                break;
        }
    }

    @Override
    public void resize(int w, int h) {
        camera.viewportWidth = w;
        camera.viewportHeight = h;
        camera.update();
    }

    @Override public void pause() {}
    @Override public void resume() {}
    @Override public void hide() {}

    @Override
    public void dispose() {
        uiBatch.dispose();
        font.dispose();
        bigFont.dispose();
        worldBuilder.dispose();
        customerSystem.dispose();
        cookingStation.dispose();
    }
}
