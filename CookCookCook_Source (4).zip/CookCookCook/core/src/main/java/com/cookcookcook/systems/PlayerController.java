package com.cookcookcook.systems;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.math.*;

public class PlayerController extends InputAdapter {

    private final PerspectiveCamera camera;
    private final float MOVE_SPEED = 5f;
    private final float LOOK_SPEED = 0.2f;
    private final float MIN_Y = 1.5f;
    private final float BOUND_X = 10f;
    private final float BOUND_Z_MIN = -14f;
    private final float BOUND_Z_MAX = 8f;

    private final Vector3 tmp = new Vector3();

    public PlayerController(PerspectiveCamera camera) {
        this.camera = camera;
    }

    public void update(float delta) {
        Vector3 direction = new Vector3(camera.direction).nor();
        direction.y = 0f;
        direction.nor();

        Vector3 right = new Vector3(camera.direction).crs(camera.up).nor();
        right.y = 0f;
        right.nor();

        if (Gdx.input.isKeyPressed(Input.Keys.W)) camera.position.mulAdd(direction,  MOVE_SPEED * delta);
        if (Gdx.input.isKeyPressed(Input.Keys.S)) camera.position.mulAdd(direction, -MOVE_SPEED * delta);
        if (Gdx.input.isKeyPressed(Input.Keys.A)) camera.position.mulAdd(right,     -MOVE_SPEED * delta);
        if (Gdx.input.isKeyPressed(Input.Keys.D)) camera.position.mulAdd(right,      MOVE_SPEED * delta);

        camera.position.x = MathUtils.clamp(camera.position.x, -BOUND_X, BOUND_X);
        camera.position.z = MathUtils.clamp(camera.position.z, BOUND_Z_MIN, BOUND_Z_MAX);
        camera.position.y = MIN_Y;

        if (Gdx.input.isButtonPressed(Input.Buttons.RIGHT)) {
            float dx = Gdx.input.getDeltaX() * LOOK_SPEED;
            float dy = Gdx.input.getDeltaY() * LOOK_SPEED;

            // Horizontal rotation around Y axis
            camera.direction.rotate(Vector3.Y, -dx);

            // Vertical rotation - clamp by checking Y component
            Vector3 r = new Vector3(camera.direction).crs(camera.up).nor();
            Vector3 testDir = new Vector3(camera.direction).rotate(r, dy);
            // Only apply if we're not looking too far up or down
            if (testDir.y > -0.95f && testDir.y < 0.95f) {
                camera.direction.set(testDir).nor();
            }
        }

        camera.update();
    }
}
