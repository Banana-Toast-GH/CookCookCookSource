package com.cookcookcook.screens;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.g3d.*;
import com.badlogic.gdx.graphics.g3d.attributes.*;
import com.badlogic.gdx.graphics.g3d.environment.*;
import com.badlogic.gdx.graphics.g3d.utils.*;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.utils.*;
import com.cookcookcook.CookCookCookGame;

public class AscensionScreen implements Screen {

    private final CookCookCookGame game;
    private SpriteBatch batch;
    private BitmapFont titleFont;
    private BitmapFont bodyFont;
    private BitmapFont smallFont;

    private float timer = 0f;
    private float alpha = 0f;
    private int selectedPedestal = -1;
    private boolean chosen = false;
    private float chosenTimer = 0f;

    // The 6 divine powers
    private static final String[] POWER_NAMES = {
        "THE TONGUE OF GODS",
        "INFINITE YIELD",
        "MARKET DOMINION",
        "STAFF BINDING",
        "COSMIC RECIPE",
        "GREED MADE FLESH"
    };

    private static final String[] POWER_DESCRIPTIONS = {
        "Customers pay 3x more.\nThey taste divinity in your food.",
        "Ingredients never run out.\nThe shop bends to your will.",
        "Stock prices move when you move.\nThe market fears you.",
        "Staff work faster.\nThey no longer question orders.",
        "Unlock alien and god recipes.\nThey eat from new worlds.",
        "Greed fills 2x faster.\nYour next ascension comes sooner."
    };

    // Pedestal positions on screen (6 in a row)
    private float[] pedestalX = new float[6];
    private float pedestalY;
    private float pedestalW = 160f;
    private float pedestalH = 220f;

    // Flash effect when chosen
    private float flashAlpha = 0f;

    public AscensionScreen(CookCookCookGame game) {
        this.game = game;
    }

    @Override
    public void show() {
        batch = new SpriteBatch();
        titleFont = new BitmapFont();
        bodyFont = new BitmapFont();
        smallFont = new BitmapFont();

        titleFont.getData().setScale(3.5f);
        bodyFont.getData().setScale(1.3f);
        smallFont.getData().setScale(1.0f);

        int w = Gdx.graphics.getWidth();
        int h = Gdx.graphics.getHeight();
        float totalWidth = 6 * pedestalW + 5 * 20f;
        float startX = (w - totalWidth) / 2f;
        pedestalY = h / 2f - 160f;

        for (int i = 0; i < 6; i++) {
            pedestalX[i] = startX + i * (pedestalW + 20f);
        }
    }

    @Override
    public void render(float delta) {
        timer += delta;

        // Fade in
        if (!chosen) {
            alpha = Math.min(1f, alpha + delta * 0.8f);
        } else {
            chosenTimer += delta;
            flashAlpha = Math.min(1f, flashAlpha + delta * 2f);
            if (chosenTimer > 2.5f) {
                // Reset & go back to game with power
                CookCookCookGame.prestige++;
                CookCookCookGame.greedLevel = 0f;
                CookCookCookGame.money = 50f + (CookCookCookGame.prestige * 25f);
                CookCookCookGame.day = 1;
                if (selectedPedestal >= 0) {
                    CookCookCookGame.prestigePowers[Math.min(selectedPedestal, 5)] = POWER_NAMES[selectedPedestal];
                }
                game.setScreen(new GameScreen(game));
                dispose();
                return;
            }
        }

        // Background: blinding white
        float bgR = 0.97f + 0.03f * (float)Math.sin(timer * 0.5f);
        Gdx.gl.glClearColor(bgR, bgR, bgR, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        batch.begin();

        // Title
        if (!chosen) {
            titleFont.setColor(0.1f, 0.05f, 0.02f, alpha);
            String title = "YOU HAVE ASCENDED.";
            GlyphLayout gl = new GlyphLayout(titleFont, title);
            titleFont.draw(batch, title,
                (Gdx.graphics.getWidth() - gl.width) / 2f,
                Gdx.graphics.getHeight() - 80f);

            bodyFont.setColor(0.3f, 0.2f, 0.1f, alpha * (0.6f + 0.4f * (float)Math.sin(timer * 2f)));
            String sub = "Choose your power. Choose wisely. You cannot undo this.";
            GlyphLayout sl = new GlyphLayout(bodyFont, sub);
            bodyFont.draw(batch, sub,
                (Gdx.graphics.getWidth() - sl.width) / 2f,
                Gdx.graphics.getHeight() - 140f);

            // Mouse position
            float mx = Gdx.input.getX();
            float my = Gdx.graphics.getHeight() - Gdx.input.getY();

            // Draw 6 pedestals
            for (int i = 0; i < 6; i++) {
                float px = pedestalX[i];
                float py = pedestalY;
                boolean hover = mx >= px && mx <= px + pedestalW && my >= py && my <= py + pedestalH;

                // Pedestal background
                float glow = hover ? 1f : 0.85f;
                float[] col = getPedestalColor(i);
                batch.setColor(col[0] * glow, col[1] * glow, col[2] * glow, alpha);

                // Draw pedestal as colored rect (replace with texture in final)
                drawRect(batch, px, py, pedestalW, pedestalH);

                // Number
                batch.setColor(1f, 1f, 1f, alpha);
                titleFont.setColor(1f, 1f, 1f, alpha);
                titleFont.getData().setScale(2f);
                titleFont.draw(batch, String.valueOf(i + 1), px + pedestalW / 2f - 10f, py + pedestalH - 10f);
                titleFont.getData().setScale(3.5f);

                // Power name
                smallFont.setColor(1f, 1f, 1f, alpha);
                String[] nameLines = POWER_NAMES[i].split(" ");
                float lineY = py + pedestalH - 60f;
                for (String line : nameLines) {
                    GlyphLayout ll = new GlyphLayout(smallFont, line);
                    smallFont.draw(batch, line, px + (pedestalW - ll.width) / 2f, lineY);
                    lineY -= 20f;
                }

                // Description on hover
                if (hover) {
                    smallFont.setColor(0.9f, 0.85f, 0.7f, alpha);
                    String[] descLines = POWER_DESCRIPTIONS[i].split("\n");
                    float dy = py - 20f;
                    for (String line : descLines) {
                        GlyphLayout dl = new GlyphLayout(smallFont, line);
                        smallFont.draw(batch, line, px + (pedestalW - dl.width) / 2f, dy);
                        dy -= 22f;
                    }
                }

                // Click
                if (hover && Gdx.input.isButtonJustPressed(Input.Buttons.LEFT) && alpha >= 0.9f) {
                    selectedPedestal = i;
                    chosen = true;
                }

                batch.setColor(1f, 1f, 1f, 1f);
            }
        } else {
            // Flash white and show power name
            batch.setColor(1f, 1f, 1f, flashAlpha);
            drawRect(batch, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
            batch.setColor(1f, 1f, 1f, 1f);

            if (flashAlpha > 0.5f) {
                float[] col = getPedestalColor(selectedPedestal);
                titleFont.setColor(col[0], col[1], col[2], flashAlpha);
                String chosen_text = "POWER GRANTED:";
                GlyphLayout cl = new GlyphLayout(titleFont, chosen_text);
                titleFont.draw(batch, chosen_text,
                    (Gdx.graphics.getWidth() - cl.width) / 2f,
                    Gdx.graphics.getHeight() / 2f + 80f);
                titleFont.getData().setScale(2.5f);
                titleFont.setColor(0.1f, 0.05f, 0.02f, flashAlpha);
                GlyphLayout pn = new GlyphLayout(titleFont, POWER_NAMES[selectedPedestal]);
                titleFont.draw(batch, POWER_NAMES[selectedPedestal],
                    (Gdx.graphics.getWidth() - pn.width) / 2f,
                    Gdx.graphics.getHeight() / 2f);
                titleFont.getData().setScale(3.5f);

                bodyFont.setColor(0.4f, 0.3f, 0.1f, flashAlpha);
                bodyFont.draw(batch, "You wake. You are stronger now.",
                    Gdx.graphics.getWidth() / 2f - 200f,
                    Gdx.graphics.getHeight() / 2f - 60f);
            }
        }

        batch.end();
    }

    private void drawRect(SpriteBatch b, float x, float y, float w, float h) {
        // Draws a solid rect using the white pixel trick
        Texture white = getWhiteTexture();
        b.draw(white, x, y, w, h);
    }

    private Texture whiteTexture;
    private Texture getWhiteTexture() {
        if (whiteTexture == null) {
            Pixmap p = new Pixmap(1, 1, Pixmap.Format.RGBA8888);
            p.setColor(Color.WHITE);
            p.fill();
            whiteTexture = new Texture(p);
            p.dispose();
        }
        return whiteTexture;
    }

    private float[] getPedestalColor(int i) {
        float[][] colors = {
            {0.8f, 0.6f, 0.1f},   // gold
            {0.2f, 0.75f, 0.3f},  // green
            {0.3f, 0.3f, 0.9f},   // blue
            {0.7f, 0.2f, 0.2f},   // red
            {0.6f, 0.2f, 0.8f},   // purple
            {0.9f, 0.4f, 0.05f},  // orange
        };
        return colors[i];
    }

    @Override public void resize(int w, int h) {}
    @Override public void pause() {}
    @Override public void resume() {}
    @Override public void hide() {}

    @Override
    public void dispose() {
        batch.dispose();
        titleFont.dispose();
        bodyFont.dispose();
        smallFont.dispose();
        if (whiteTexture != null) whiteTexture.dispose();
    }
}
