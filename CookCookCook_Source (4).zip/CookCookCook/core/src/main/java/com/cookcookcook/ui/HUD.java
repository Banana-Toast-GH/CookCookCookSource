package com.cookcookcook.ui;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.math.*;
import com.cookcookcook.CookCookCookGame;
import com.cookcookcook.screens.GameScreen.GameState;

public class HUD {

    private final BitmapFont font;
    private final BitmapFont bigFont;
    private Texture whiteTexture;
    private float pulseTimer = 0f;

    // Greed bar colors
    private static final Color[] GREED_COLORS = {
        new Color(0.3f, 0.8f, 0.3f, 1f),  // 0-30: green
        new Color(0.9f, 0.75f, 0.1f, 1f), // 30-60: yellow
        new Color(0.9f, 0.4f, 0.1f, 1f),  // 60-85: orange
        new Color(0.8f, 0.1f, 0.1f, 1f),  // 85-100: red
    };

    public HUD(BitmapFont font, BitmapFont bigFont) {
        this.font = font;
        this.bigFont = bigFont;
        Pixmap p = new Pixmap(1, 1, Pixmap.Format.RGBA8888);
        p.setColor(Color.WHITE);
        p.fill();
        whiteTexture = new Texture(p);
        p.dispose();
    }

    public void render(SpriteBatch batch, GameState state, String interactionPrompt,
                       float dayTimer, float dayLength) {
        pulseTimer += Gdx.graphics.getDeltaTime();
        int w = Gdx.graphics.getWidth();
        int h = Gdx.graphics.getHeight();

        // === TOP LEFT: Money + Day ===
        batch.setColor(0f, 0f, 0f, 0.55f);
        batch.draw(whiteTexture, 10f, h - 65f, 240f, 55f);
        batch.setColor(0.4f, 0.9f, 0.4f, 1f);
        bigFont.setColor(0.4f, 0.95f, 0.4f, 1f);
        bigFont.getData().setScale(1.5f);
        bigFont.draw(batch, "$" + String.format("%.2f", CookCookCookGame.money), 18f, h - 18f);
        bigFont.getData().setScale(2f);
        font.setColor(0.8f, 0.8f, 0.8f, 1f);
        font.draw(batch, "Day " + CookCookCookGame.day + " | Served: " + CookCookCookGame.totalCustomersServed,
            18f, h - 45f);

        // === TOP CENTER: Day progress bar ===
        float dayPct = dayTimer / dayLength;
        float barW = 300f;
        float barX = w / 2f - barW / 2f;
        float barY = h - 30f;
        batch.setColor(0f, 0f, 0f, 0.5f);
        batch.draw(whiteTexture, barX, barY, barW, 16f);
        // Lerp color: morning=warm, evening=dark
        float r = 0.95f - dayPct * 0.5f;
        float g = 0.75f - dayPct * 0.5f;
        float b2 = 0.3f + dayPct * 0.3f;
        batch.setColor(r, g, b2, 1f);
        batch.draw(whiteTexture, barX, barY, barW * dayPct, 16f);
        font.setColor(1f, 1f, 1f, 0.9f);
        font.draw(batch, "Day", barX - 35f, barY + 14f);
        font.draw(batch, "End", barX + barW + 5f, barY + 14f);

        // === TOP RIGHT: Greed meter ===
        float greed = CookCookCookGame.greedLevel;
        float greedBarH = 120f;
        float greedBarX = w - 40f;
        float greedBarY = h - 140f;
        float greedBarW = 18f;

        batch.setColor(0f, 0f, 0f, 0.55f);
        batch.draw(whiteTexture, greedBarX - 5f, greedBarY - 5f, greedBarW + 10f, greedBarH + 30f);

        // Bar bg
        batch.setColor(0.15f, 0.15f, 0.15f, 1f);
        batch.draw(whiteTexture, greedBarX, greedBarY, greedBarW, greedBarH);

        // Bar fill
        Color gc = getGreedColor(greed);
        float pulse = greed > 80f ? 0.8f + 0.2f * (float)Math.sin(pulseTimer * 6f) : 1f;
        batch.setColor(gc.r * pulse, gc.g * pulse, gc.b * pulse, 1f);
        batch.draw(whiteTexture, greedBarX, greedBarY, greedBarW, greedBarH * (greed / 100f));

        // Label
        font.setColor(gc.r, gc.g, gc.b, 1f);
        font.draw(batch, "GREED", greedBarX - 20f, greedBarY + greedBarH + 20f);
        font.draw(batch, (int)greed + "%", greedBarX - 10f, greedBarY - 5f);

        // === BOTTOM: Interaction prompt ===
        if (interactionPrompt != null && !interactionPrompt.isEmpty() && state == GameState.EXPLORING) {
            float promptAlpha = 0.75f + 0.25f * (float)Math.sin(pulseTimer * 4f);
            GlyphLayout gl = new GlyphLayout(font, interactionPrompt);
            float promptX = w / 2f - gl.width / 2f - 10f;
            float promptY = 80f;

            batch.setColor(0f, 0f, 0f, 0.65f * promptAlpha);
            batch.draw(whiteTexture, promptX - 8f, promptY - 20f, gl.width + 20f, 32f);

            font.setColor(1f, 0.95f, 0.7f, promptAlpha);
            font.draw(batch, interactionPrompt, promptX, promptY);
        }

        // === BOTTOM LEFT: Controls reminder ===
        if (state == GameState.EXPLORING) {
            batch.setColor(0f, 0f, 0f, 0.4f);
            batch.draw(whiteTexture, 10f, 10f, 280f, 55f);
            font.setColor(0.55f, 0.55f, 0.55f, 0.85f);
            font.draw(batch, "WASD: Move  Right-click: Look", 15f, 55f);
            font.draw(batch, "E: Interact  K: Quick knife  ESC: Menu", 15f, 30f);
        }

        // === PRESTIGE indicator ===
        if (CookCookCookGame.prestige > 0) {
            font.setColor(0.9f, 0.7f, 0.1f, 0.9f);
            font.draw(batch, "✦ ASCENDED x" + CookCookCookGame.prestige, w - 200f, 30f);
        }

        // === WARNING: Greed near max ===
        if (greed >= 85f) {
            float warnAlpha = 0.5f + 0.5f * (float)Math.sin(pulseTimer * 8f);
            font.setColor(0.9f, 0.1f, 0.1f, warnAlpha);
            GlyphLayout wl = new GlyphLayout(font, "ASCENSION APPROACHING");
            font.draw(batch, "ASCENSION APPROACHING", w / 2f - wl.width / 2f, 120f);
        }

        batch.setColor(1f, 1f, 1f, 1f);
    }

    private Color getGreedColor(float greed) {
        if (greed < 30f) return GREED_COLORS[0];
        if (greed < 60f) return GREED_COLORS[1];
        if (greed < 85f) return GREED_COLORS[2];
        return GREED_COLORS[3];
    }

    public void dispose() {
        if (whiteTexture != null) whiteTexture.dispose();
    }
}
