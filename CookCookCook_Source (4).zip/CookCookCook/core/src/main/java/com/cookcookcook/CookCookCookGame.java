package com.cookcookcook;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.environment.PointLight;
import com.cookcookcook.screens.*;

public class CookCookCookGame extends Game {

    public static AssetManager assets;
    public static ModelBatch modelBatch;
    public static Environment environment;

    // Game state
    public static float money = 50f;
    public static int day = 1;
    public static long totalCustomersServed = 0;
    public static float greedLevel = 0f; // 0-100, drives the lore progression
    public static int prestige = 0; // how many times you've ascended
    public static String[] prestigePowers = new String[6];

    @Override
    public void create() {
        assets = new AssetManager();
        modelBatch = new ModelBatch();

        environment = new Environment();
        environment.set(new ColorAttribute(ColorAttribute.AmbientLight, 0.5f, 0.48f, 0.45f, 1f));
        environment.add(new DirectionalLight().set(1f, 0.95f, 0.85f, -1f, -0.8f, -0.2f));
        environment.add(new PointLight().set(1f, 0.9f, 0.6f, 0f, 3f, 0f, 30f));

        setScreen(new SplashScreen(this));
    }

    @Override
    public void dispose() {
        super.dispose();
        assets.dispose();
        modelBatch.dispose();
    }
}
