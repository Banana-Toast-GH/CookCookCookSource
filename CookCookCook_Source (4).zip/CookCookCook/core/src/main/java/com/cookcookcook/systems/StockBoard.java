package com.cookcookcook.systems;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.utils.*;
import com.cookcookcook.CookCookCookGame;

public class StockBoard {

    public static class Stock {
        public String symbol;
        public String name;
        public float price;
        public float change;
        public float[] history; // last 30 days
        public int historyIdx;
        public int sharesOwned;
        public boolean isFood;

        public Stock(String symbol, String name, float startPrice, boolean isFood) {
            this.symbol = symbol;
            this.name = name;
            this.price = startPrice;
            this.change = 0f;
            this.history = new float[30];
            this.historyIdx = 0;
            for (int i = 0; i < 30; i++) history[i] = startPrice;
            this.isFood = isFood;
        }

        public void recordHistory() {
            history[historyIdx % 30] = price;
            historyIdx++;
        }
    }

    private Array<Stock> stocks = new Array<>();
    private int selectedStock = 0;
    private int investAmount = 1;
    private Texture whiteTexture;

    public StockBoard() {
        Pixmap p = new Pixmap(1, 1, Pixmap.Format.RGBA8888);
        p.setColor(Color.WHITE);
        p.fill();
        whiteTexture = new Texture(p);
        p.dispose();

        initStocks();
    }

    private void initStocks() {
        stocks.add(new Stock("BRGS", "BurgerCorp", 45f, true));
        stocks.add(new Stock("NOOD", "NoodleNation", 22f, true));
        stocks.add(new Stock("TACO", "TacoWorld Inc.", 18f, true));
        stocks.add(new Stock("SUSH", "Sushi Galaxy", 67f, true));
        stocks.add(new Stock("BAKE", "Bake Street", 30f, true));
        stocks.add(new Stock("CHEM", "FoodLabs Corp", 120f, false));
        stocks.add(new Stock("ALIM", "Alimental Inc.", 200f, false)); // alien food
        stocks.add(new Stock("DIVN", "Divine Sustenance LLC", 999f, false)); // god food
    }

    public void simulateMarket() {
        for (Stock s : stocks) {
            // Base random drift
            float drift = MathUtils.randomSign() * MathUtils.random(0.5f, 5f);

            // Greed affects food stocks positively
            if (s.isFood) {
                drift += CookCookCookGame.greedLevel * 0.05f;
            }

            // Market dominion power
            boolean hasDominion = false;
            for (String p : CookCookCookGame.prestigePowers) {
                if ("MARKET DOMINION".equals(p)) { hasDominion = true; break; }
            }
            if (hasDominion) drift = Math.abs(drift) * 1.5f; // always goes up

            s.change = drift;
            s.price = Math.max(1f, s.price + drift);
            s.recordHistory();
        }
    }

    public void update(float delta) {
        if (!isVisible()) return;

        if (Gdx.input.isKeyJustPressed(Input.Keys.UP)) selectedStock = Math.max(0, selectedStock - 1);
        if (Gdx.input.isKeyJustPressed(Input.Keys.DOWN)) selectedStock = Math.min(stocks.size - 1, selectedStock + 1);
        if (Gdx.input.isKeyJustPressed(Input.Keys.LEFT)) investAmount = Math.max(1, investAmount - 1);
        if (Gdx.input.isKeyJustPressed(Input.Keys.RIGHT)) investAmount = Math.min(100, investAmount + 1);

        Stock sel = stocks.get(selectedStock);

        // Buy
        if (Gdx.input.isKeyJustPressed(Input.Keys.B)) {
            float cost = sel.price * investAmount;
            if (CookCookCookGame.money >= cost) {
                CookCookCookGame.money -= cost;
                sel.sharesOwned += investAmount;
            }
        }

        // Sell
        if (Gdx.input.isKeyJustPressed(Input.Keys.S)) {
            int toSell = Math.min(investAmount, sel.sharesOwned);
            if (toSell > 0) {
                CookCookCookGame.money += sel.price * toSell;
                sel.sharesOwned -= toSell;
            }
        }
    }

    private boolean visible = false;
    public boolean isVisible() { return visible; }

    public void renderUI(SpriteBatch batch, BitmapFont font, BitmapFont bigFont) {
        visible = true;
        int w = Gdx.graphics.getWidth();
        int h = Gdx.graphics.getHeight();

        // Background
        batch.setColor(0.04f, 0.06f, 0.04f, 0.95f);
        batch.draw(whiteTexture, 20f, 20f, w - 40f, h - 40f);

        // Border - green like a terminal
        batch.setColor(0.1f, 0.6f, 0.15f, 1f);
        drawBorder(batch, 20f, 20f, w - 40f, h - 40f, 2f);

        bigFont.setColor(0.1f, 0.9f, 0.2f, 1f);
        bigFont.draw(batch, "COOK MARKET EXCHANGE", 40f, h - 40f);

        font.setColor(0.3f, 0.8f, 0.3f, 1f);
        font.draw(batch, "Cash: $" + String.format("%.2f", CookCookCookGame.money), 40f, h - 75f);
        font.draw(batch, "Day: " + CookCookCookGame.day, 300f, h - 75f);
        font.draw(batch, "Greed Level: " + (int)CookCookCookGame.greedLevel + "%", 450f, h - 75f);

        // Stock list
        float listX = 40f;
        float listStartY = h - 110f;
        float rowH = 28f;

        font.setColor(0.5f, 0.8f, 0.5f, 1f);
        font.draw(batch, "SYMBOL    NAME                   PRICE      CHANGE    OWNED", listX, listStartY);

        for (int i = 0; i < stocks.size; i++) {
            Stock s = stocks.get(i);
            float rowY = listStartY - (i + 1) * rowH;

            if (i == selectedStock) {
                batch.setColor(0.1f, 0.25f, 0.1f, 0.8f);
                batch.draw(whiteTexture, listX - 5f, rowY - 18f, w - 90f, rowH);
            }

            boolean up = s.change >= 0;
            font.setColor(up ? 0.2f : 0.9f, up ? 0.9f : 0.2f, 0.2f, 1f);

            String changeStr = (up ? "+" : "") + String.format("%.2f", s.change);
            font.draw(batch, String.format("%-10s %-22s $%-10.2f %s          %d",
                s.symbol, s.name, s.price, changeStr, s.sharesOwned), listX, rowY);
        }

        // Selected stock chart
        Stock sel = stocks.get(selectedStock);
        float chartX = 40f;
        float chartY = 80f;
        float chartW = w - 400f;
        float chartH = 200f;

        // Chart bg
        batch.setColor(0.02f, 0.04f, 0.02f, 1f);
        batch.draw(whiteTexture, chartX, chartY, chartW, chartH);
        batch.setColor(0.1f, 0.4f, 0.1f, 0.5f);
        drawBorder(batch, chartX, chartY, chartW, chartH, 1f);

        // Plot price history
        float[] hist = sel.history;
        float minP = Float.MAX_VALUE, maxP = Float.MIN_VALUE;
        for (float v : hist) { minP = Math.min(minP, v); maxP = Math.max(maxP, v); }
        float range = Math.max(1f, maxP - minP);

        for (int i = 1; i < 30; i++) {
            float x1 = chartX + (i - 1) / 29f * chartW;
            float x2 = chartX + i / 29f * chartW;
            float y1 = chartY + ((hist[(sel.historyIdx + i - 1) % 30] - minP) / range) * chartH;
            float y2 = chartY + ((hist[(sel.historyIdx + i) % 30] - minP) / range) * chartH;

            batch.setColor(0.2f, 1f, 0.3f, 1f);
            // Draw line as small rect
            float len = (float)Math.sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));
            batch.draw(whiteTexture, x1, Math.min(y1, y2), len, Math.abs(y2 - y1) + 2f);
        }

        // Stock info panel
        float infoX = chartX + chartW + 20f;
        bigFont.setColor(0.2f, 0.9f, 0.3f, 1f);
        bigFont.getData().setScale(1.4f);
        bigFont.draw(batch, sel.symbol, infoX, 280f);
        bigFont.getData().setScale(2f);

        font.setColor(0.7f, 0.7f, 0.7f, 1f);
        font.draw(batch, sel.name, infoX, 255f);
        font.draw(batch, "$" + String.format("%.2f", sel.price), infoX, 230f);
        font.setColor(sel.change >= 0 ? Color.GREEN : Color.RED);
        font.draw(batch, (sel.change >= 0 ? "▲" : "▼") + " " + String.format("%.2f", Math.abs(sel.change)), infoX, 208f);

        font.setColor(0.6f, 0.6f, 0.6f, 1f);
        font.draw(batch, "Qty: " + investAmount + " (← →)", infoX, 180f);
        font.setColor(0.3f, 0.9f, 0.3f, 1f);
        font.draw(batch, "[B] Buy  $" + String.format("%.2f", sel.price * investAmount), infoX, 155f);
        font.setColor(0.9f, 0.3f, 0.3f, 1f);
        font.draw(batch, "[S] Sell  (" + sel.sharesOwned + " owned)", infoX, 130f);

        font.setColor(0.4f, 0.4f, 0.4f, 1f);
        font.draw(batch, "[ESC] Close", infoX, 95f);

        batch.setColor(1f, 1f, 1f, 1f);
    }

    private void drawBorder(SpriteBatch b, float x, float y, float w, float h, float t) {
        b.draw(whiteTexture, x, y, w, t);
        b.draw(whiteTexture, x, y + h - t, w, t);
        b.draw(whiteTexture, x, y, t, h);
        b.draw(whiteTexture, x + w - t, y, t, h);
    }

    public void dispose() {
        if (whiteTexture != null) whiteTexture.dispose();
    }
}
