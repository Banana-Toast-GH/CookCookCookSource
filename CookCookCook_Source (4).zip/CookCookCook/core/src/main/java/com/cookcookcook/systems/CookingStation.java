package com.cookcookcook.systems;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.utils.*;
import com.cookcookcook.CookCookCookGame;

public class CookingStation {

    // State
    public enum CookingPhase { NONE, KNIFE, BOIL, COMPLETE }
    private CookingPhase phase = CookingPhase.NONE;
    private boolean minigameComplete = false;
    private boolean complete = false;
    private String readyFood = null;
    private Array<String> currentIngredients = new Array<>();

    // Knife minigame
    private float knifeBarPos = 0f;       // 0-1 position on bar
    private float knifeBarSpeed = 0.8f;
    private int knifeDirection = 1;
    private float knifeGreenStart = 0.35f;
    private float knifeGreenEnd = 0.65f;
    private int knifeHits = 0;
    private int knifeRequired = 3;
    private float knifeFlashTimer = 0f;
    private boolean knifeHitSuccess = false;

    // Boil minigame
    private float boilHeat = 0.3f;        // 0-1 heat level
    private float boilGreenStart = 0.4f;
    private float boilGreenEnd = 0.7f;
    private float boilDriftSpeed = 0.12f; // natural drift
    private float boilTimer = 0f;
    private float boilRequired = 8f;      // seconds in green
    private float boilInGreenTime = 0f;
    private boolean boilHolding = false;
    private boolean boilBurned = false;

    // Food combination engine
    private static final String[][] COMBOS = {
        {"bread", "meat", "cheese"},       // Classic Burger
        {"noodles", "broth", "egg"},        // Ramen
        {"tortilla", "beans", "salsa"},     // Taco Supreme
        {"dough", "tomato", "cheese"},      // Original Pizza
        {"rice", "fish", "seaweed"},        // Sushi Roll
        {"bread", "egg", "bacon"},          // Breakfast Stack
        // Alien combos (unlocked by prestige)
        {"xenofruit", "plasma", "void"},    // Void Stew (alien)
        {"stardust", "light", "salt"},      // Star Soup
        // God combos
        {"eternity", "hunger", "worship"},  // Ambrosia of Gods
    };

    private static final String[] COMBO_NAMES = {
        "Classic Burger", "Ramen Bowl", "Taco Supreme", "Original Pizza",
        "Sushi Roll", "Breakfast Stack", "Void Stew", "Star Soup", "Ambrosia of Gods"
    };

    // For "new substance" invention - unknown combos get creative names
    private static final String[] INVENTION_PREFIXES = {
        "Glorp", "Smash", "Flux", "Hyper", "Mega", "Ultra", "Turbo", "Omega"
    };
    private static final String[] INVENTION_SUFFIXES = {
        " Blob", " Slurry", " Supreme", " X", " Pudding", " Matter", " Gunk", " Fusion"
    };

    // White pixel for drawing bars
    private Texture whiteTexture;

    public CookingStation() {
        Pixmap p = new Pixmap(1, 1, Pixmap.Format.RGBA8888);
        p.setColor(Color.WHITE);
        p.fill();
        whiteTexture = new Texture(p);
        p.dispose();
    }

    public void startCooking(Array<String> ingredients) {
        currentIngredients.clear();
        currentIngredients.addAll(ingredients);
        complete = false;
        readyFood = null;
        knifeHits = 0;
        boilInGreenTime = 0f;
        boilBurned = false;
        phase = CookingPhase.KNIFE;
        startKnifeMinigame();
    }

    public void startKnifeMinigame() {
        knifeBarPos = 0f;
        knifeDirection = 1;
        knifeHits = 0;
        knifeFlashTimer = 0f;
        phase = CookingPhase.KNIFE;
        minigameComplete = false;

        // Scale difficulty with greed
        knifeBarSpeed = 0.8f + CookCookCookGame.greedLevel * 0.008f;
        knifeRequired = 3 + (int)(CookCookCookGame.greedLevel / 20f);
        // Shrink green zone as difficulty grows
        float greenSize = Math.max(0.12f, 0.3f - CookCookCookGame.greedLevel * 0.002f);
        knifeGreenStart = 0.5f - greenSize / 2f;
        knifeGreenEnd = 0.5f + greenSize / 2f;
    }

    public void update(float delta) {
        if (phase == CookingPhase.NONE || phase == CookingPhase.COMPLETE) return;

        if (phase == CookingPhase.KNIFE) {
            updateKnife(delta);
        } else if (phase == CookingPhase.BOIL) {
            updateBoil(delta);
        }
    }

    public void updateMinigame(float delta) {
        update(delta);
    }

    private void updateKnife(float delta) {
        knifeBarPos += knifeDirection * knifeBarSpeed * delta;
        if (knifeBarPos >= 1f) { knifeBarPos = 1f; knifeDirection = -1; }
        if (knifeBarPos <= 0f) { knifeBarPos = 0f; knifeDirection = 1; }

        if (knifeFlashTimer > 0f) knifeFlashTimer -= delta;

        // SPACE or click to chop
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE) || Gdx.input.justTouched()) {
            if (knifeBarPos >= knifeGreenStart && knifeBarPos <= knifeGreenEnd) {
                knifeHits++;
                knifeHitSuccess = true;
                knifeFlashTimer = 0.2f;
                if (knifeHits >= knifeRequired) {
                    // Move to boiling phase
                    phase = CookingPhase.BOIL;
                    minigameComplete = false;
                    boilInGreenTime = 0f;
                    boilHeat = 0.3f;
                }
            } else {
                knifeHitSuccess = false;
                knifeFlashTimer = 0.2f;
                // Miss = penalty, flash red
            }
        }
    }

    private void updateBoil(float delta) {
        // Natural heat drift up
        boilHeat += boilDriftSpeed * delta;

        // SPACE held = lower heat (add cold)
        boilHolding = Gdx.input.isKeyPressed(Input.Keys.SPACE);
        if (boilHolding) {
            boilHeat -= 0.3f * delta;
        }

        boilHeat = MathUtils.clamp(boilHeat, 0f, 1f);

        // Check if in green zone
        if (boilHeat >= boilGreenStart && boilHeat <= boilGreenEnd) {
            boilInGreenTime += delta;
        } else if (boilHeat > boilGreenEnd + 0.2f) {
            boilBurned = true;
            // Burned = new substance name
        }

        boilTimer += delta;

        // Complete after required time in green
        if (boilInGreenTime >= boilRequired) {
            finishCooking();
        }
    }

    private void finishCooking() {
        phase = CookingPhase.COMPLETE;
        complete = true;
        readyFood = determineFoodName();
        CookCookCookGame.greedLevel = Math.min(100f, CookCookCookGame.greedLevel + 1f);
    }

    private String determineFoodName() {
        if (boilBurned) {
            // "New substance" - invention
            String prefix = INVENTION_PREFIXES[MathUtils.random(INVENTION_PREFIXES.length - 1)];
            String suffix = INVENTION_SUFFIXES[MathUtils.random(INVENTION_SUFFIXES.length - 1)];
            return prefix + suffix;
        }

        // Try to match known combo
        for (int i = 0; i < COMBOS.length; i++) {
            int matches = 0;
            for (String need : COMBOS[i]) {
                for (String have : currentIngredients) {
                    if (have.toLowerCase().contains(need.toLowerCase())) matches++;
                }
            }
            if (matches >= 2) return COMBO_NAMES[i];
        }

        // Random creation
        if (currentIngredients.size >= 2) {
            return currentIngredients.get(0) + "-" + currentIngredients.get(1) + " Special";
        }
        return "Mystery Dish";
    }

    public void renderUI(SpriteBatch batch, BitmapFont font, BitmapFont bigFont) {
        if (phase == CookingPhase.COMPLETE) {
            // Show what was cooked
            bigFont.setColor(0.1f, 0.5f, 0.1f, 1f);
            bigFont.draw(batch, "Cooked: " + readyFood,
                Gdx.graphics.getWidth() / 2f - 150f,
                Gdx.graphics.getHeight() / 2f + 50f);
            font.setColor(0.5f, 0.5f, 0.5f, 1f);
            font.draw(batch, "Serve the customer! [E] at the window",
                Gdx.graphics.getWidth() / 2f - 160f,
                Gdx.graphics.getHeight() / 2f);
        }
    }

    public void renderMinigameUI(SpriteBatch batch, BitmapFont font, BitmapFont bigFont) {
        int w = Gdx.graphics.getWidth();
        int h = Gdx.graphics.getHeight();

        // Dim overlay
        batch.setColor(0f, 0f, 0f, 0.6f);
        batch.draw(whiteTexture, 0, 0, w, h);
        batch.setColor(1f, 1f, 1f, 1f);

        if (phase == CookingPhase.KNIFE) {
            renderKnifeUI(batch, font, bigFont, w, h);
        } else if (phase == CookingPhase.BOIL) {
            renderBoilUI(batch, font, bigFont, w, h);
        }
    }

    private void renderKnifeUI(SpriteBatch batch, BitmapFont font, BitmapFont bigFont, int w, int h) {
        float barX = w / 2f - 200f;
        float barY = h / 2f - 20f;
        float barW = 400f;
        float barH = 40f;

        bigFont.setColor(1f, 0.95f, 0.8f, 1f);
        bigFont.draw(batch, "CHOP!", w / 2f - 40f, h / 2f + 100f);
        font.setColor(0.8f, 0.8f, 0.8f, 1f);
        font.draw(batch, "Press [SPACE] when the bar is in the green zone!",
            w / 2f - 220f, h / 2f + 65f);
        font.draw(batch, "Hits: " + knifeHits + " / " + knifeRequired, barX, h / 2f + 45f);

        // Bar background
        batch.setColor(0.3f, 0.3f, 0.3f, 1f);
        batch.draw(whiteTexture, barX, barY, barW, barH);

        // Green zone
        batch.setColor(0.2f, 0.8f, 0.3f, 1f);
        batch.draw(whiteTexture,
            barX + knifeGreenStart * barW, barY,
            (knifeGreenEnd - knifeGreenStart) * barW, barH);

        // Bar indicator (the moving line)
        float indW = 8f;
        batch.setColor(1f, 1f, 1f, 1f);
        batch.draw(whiteTexture, barX + knifeBarPos * barW - indW / 2f, barY - 5f, indW, barH + 10f);

        // Flash feedback
        if (knifeFlashTimer > 0f) {
            if (knifeHitSuccess) {
                batch.setColor(0.2f, 1f, 0.3f, knifeFlashTimer * 5f);
                bigFont.setColor(0.2f, 1f, 0.3f, knifeFlashTimer * 5f);
                bigFont.draw(batch, "NICE CUT!", w / 2f - 60f, h / 2f - 80f);
            } else {
                batch.setColor(1f, 0.2f, 0.2f, knifeFlashTimer * 5f);
                bigFont.setColor(1f, 0.2f, 0.2f, knifeFlashTimer * 5f);
                bigFont.draw(batch, "MISSED!", w / 2f - 50f, h / 2f - 80f);
            }
        }

        batch.setColor(1f, 1f, 1f, 1f);
    }

    private void renderBoilUI(SpriteBatch batch, BitmapFont font, BitmapFont bigFont, int w, int h) {
        float barX = w / 2f - 30f;
        float barY = h / 2f - 150f;
        float barW = 60f;
        float barH = 300f;

        bigFont.setColor(1f, 0.6f, 0.2f, 1f);
        bigFont.draw(batch, "BOIL!", w / 2f - 40f, h / 2f + 180f);
        font.setColor(0.8f, 0.8f, 0.8f, 1f);
        font.draw(batch, "Hold [SPACE] to lower heat. Keep it in the green!", w / 2f - 220f, h / 2f + 145f);

        float progressPct = boilInGreenTime / boilRequired;
        font.draw(batch, "Progress: " + (int)(progressPct * 100f) + "%", barX - 80f, h / 2f + 110f);

        if (boilBurned) {
            font.setColor(1f, 0.3f, 0.1f, 1f);
            font.draw(batch, "BURNING! New substance incoming...", barX - 80f, h / 2f - 180f);
        }

        // Bar background
        batch.setColor(0.3f, 0.3f, 0.3f, 1f);
        batch.draw(whiteTexture, barX, barY, barW, barH);

        // Green zone
        batch.setColor(0.2f, 0.8f, 0.3f, 1f);
        float gStart = barY + boilGreenStart * barH;
        float gHeight = (boilGreenEnd - boilGreenStart) * barH;
        batch.draw(whiteTexture, barX, gStart, barW, gHeight);

        // Danger zone (too hot)
        batch.setColor(0.9f, 0.2f, 0.1f, 1f);
        float dStart = barY + (boilGreenEnd + 0.1f) * barH;
        batch.draw(whiteTexture, barX, dStart, barW, barH - (boilGreenEnd + 0.1f) * barH);

        // Heat indicator
        float indH = 8f;
        float indY = barY + boilHeat * barH;
        Color heatColor = boilHeat > boilGreenEnd ? Color.RED : (boilHeat < boilGreenStart ? Color.CYAN : Color.WHITE);
        batch.setColor(heatColor);
        batch.draw(whiteTexture, barX - 5f, indY - indH / 2f, barW + 10f, indH);

        // Progress bar (horizontal, below)
        batch.setColor(0.3f, 0.3f, 0.3f, 1f);
        batch.draw(whiteTexture, barX - 60f, barY - 30f, barW + 120f, 20f);
        batch.setColor(0.3f, 0.7f, 1f, 1f);
        batch.draw(whiteTexture, barX - 60f, barY - 30f, (barW + 120f) * progressPct, 20f);

        batch.setColor(1f, 1f, 1f, 1f);
    }

    public boolean isMinigameComplete() { return minigameComplete; }
    public boolean isComplete() { return complete; }
    public boolean hasReadyFood() { return readyFood != null; }
    public String getReadyFood() { return readyFood; }
    public void consumeFood() { readyFood = null; complete = false; phase = CookingPhase.NONE; }
    public CookingPhase getPhase() { return phase; }

    public void dispose() {
        if (whiteTexture != null) whiteTexture.dispose();
    }
}
