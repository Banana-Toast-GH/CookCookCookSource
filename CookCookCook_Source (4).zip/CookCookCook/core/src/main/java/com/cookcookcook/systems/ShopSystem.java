package com.cookcookcook.systems;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.utils.*;
import com.cookcookcook.CookCookCookGame;

public class ShopSystem {

    public static class ShopItem {
        public String name;
        public float price;
        public int stock;
        public String category;
        public boolean isAlien;
        public boolean isGod;

        public ShopItem(String name, float price, int stock, String category) {
            this.name = name; this.price = price; this.stock = stock; this.category = category;
        }
    }

    private Array<ShopItem> shopItems = new Array<>();
    private Array<String> inventory = new Array<>();
    private boolean isOpen = false;
    private int selectedIndex = 0;
    private Texture whiteTexture;
    private float animTimer = 0f;

    // Shop keeper mood
    private String shopKeeperMood = "normal";
    private String[] shopKeeperDialogue = {
        "Welcome! Fresh stock today.",
        "You again? ...Sure, take what you need.",
        "I don't know what you're making, but okay.",
        "Are you... building something? Out back?",
        "I'm starting to get worried about you.",
        "WHERE DID YOU GET THAT TOWER PERMIT.",
        "I... I'm calling someone.",
        "Please. Just buy your vegetables. Nothing else.",
        "You look different. Your eyes...",
        "I don't want to know. Just pay."
    };

    public ShopSystem() {
        Pixmap p = new Pixmap(1, 1, Pixmap.Format.RGBA8888);
        p.setColor(Color.WHITE);
        p.fill();
        whiteTexture = new Texture(p);
        p.dispose();

        initShopItems();
    }

    private void initShopItems() {
        // Basic ingredients
        shopItems.add(new ShopItem("Bread", 1.5f, 20, "Baked"));
        shopItems.add(new ShopItem("Meat", 3f, 15, "Protein"));
        shopItems.add(new ShopItem("Cheese", 2f, 20, "Dairy"));
        shopItems.add(new ShopItem("Noodles", 1f, 25, "Pasta"));
        shopItems.add(new ShopItem("Broth", 2f, 15, "Liquid"));
        shopItems.add(new ShopItem("Egg", 0.5f, 30, "Protein"));
        shopItems.add(new ShopItem("Tortilla", 1f, 20, "Baked"));
        shopItems.add(new ShopItem("Beans", 1.5f, 20, "Legumes"));
        shopItems.add(new ShopItem("Rice", 1f, 25, "Grain"));
        shopItems.add(new ShopItem("Fish", 3.5f, 10, "Protein"));
        shopItems.add(new ShopItem("Tomato", 0.75f, 30, "Vegetable"));
        shopItems.add(new ShopItem("Dough", 2f, 15, "Baked"));
        shopItems.add(new ShopItem("Bacon", 2.5f, 15, "Protein"));
        shopItems.add(new ShopItem("Seaweed", 1.5f, 15, "Vegetable"));
        shopItems.add(new ShopItem("Salsa", 1.25f, 20, "Condiment"));
        shopItems.add(new ShopItem("Butter", 1f, 20, "Dairy"));
        shopItems.add(new ShopItem("Salt", 0.25f, 50, "Spice"));
        shopItems.add(new ShopItem("Pepper", 0.5f, 40, "Spice"));

        // Alien items (unlocked by greed > 40)
        ShopItem xenofruit = new ShopItem("Xenofruit", 12f, 5, "Alien");
        xenofruit.isAlien = true;
        shopItems.add(xenofruit);

        ShopItem plasma = new ShopItem("Plasma Extract", 18f, 3, "Alien");
        plasma.isAlien = true;
        shopItems.add(plasma);

        ShopItem stardust = new ShopItem("Stardust", 25f, 3, "Alien");
        stardust.isAlien = true;
        shopItems.add(stardust);

        ShopItem voidEss = new ShopItem("Void Essence", 30f, 2, "Alien");
        voidEss.isAlien = true;
        shopItems.add(voidEss);

        // God tier items (greed > 75)
        ShopItem eternity = new ShopItem("Fragment of Eternity", 100f, 1, "Divine");
        eternity.isGod = true;
        shopItems.add(eternity);

        ShopItem hunger = new ShopItem("Crystallized Hunger", 120f, 1, "Divine");
        hunger.isGod = true;
        shopItems.add(hunger);
    }

    public void open() {
        isOpen = true;
        selectedIndex = 0;
        updateShopkeeperMood();
    }

    private void updateShopkeeperMood() {
        int greedStage = (int)(CookCookCookGame.greedLevel / 10f);
        greedStage = Math.min(greedStage, shopKeeperDialogue.length - 1);
        shopKeeperMood = shopKeeperDialogue[greedStage];
    }

    public void update(float delta) {
        if (!isOpen) return;
        animTimer += delta;

        // Keyboard navigation
        if (Gdx.input.isKeyJustPressed(Input.Keys.UP)) {
            selectedIndex = Math.max(0, selectedIndex - 1);
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.DOWN)) {
            selectedIndex = Math.min(getVisibleItems().size - 1, selectedIndex + 1);
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.ENTER) || Gdx.input.isKeyJustPressed(Input.Keys.E)) {
            buySelected();
        }
    }

    private Array<ShopItem> getVisibleItems() {
        Array<ShopItem> visible = new Array<>();
        for (ShopItem item : shopItems) {
            if (item.isGod && CookCookCookGame.greedLevel < 75f) continue;
            if (item.isAlien && CookCookCookGame.greedLevel < 40f) continue;
            visible.add(item);
        }
        return visible;
    }

    private void buySelected() {
        Array<ShopItem> visible = getVisibleItems();
        if (selectedIndex >= visible.size) return;
        ShopItem item = visible.get(selectedIndex);

        // Infinite yield power
        boolean infinite = false;
        for (String p : CookCookCookGame.prestigePowers) {
            if ("INFINITE YIELD".equals(p)) { infinite = true; break; }
        }

        if (item.stock > 0 && CookCookCookGame.money >= item.price) {
            CookCookCookGame.money -= item.price;
            if (!infinite) item.stock--;
            inventory.add(item.name);
        }
    }

    public void renderUI(SpriteBatch batch, BitmapFont font, BitmapFont bigFont) {
        if (!isOpen) return;
        int w = Gdx.graphics.getWidth();
        int h = Gdx.graphics.getHeight();

        // Panel background
        batch.setColor(0.08f, 0.06f, 0.04f, 0.92f);
        batch.draw(whiteTexture, w / 2f - 300f, 60f, 600f, h - 120f);

        // Panel border
        batch.setColor(0.6f, 0.5f, 0.2f, 1f);
        drawBorder(batch, w / 2f - 300f, 60f, 600f, h - 120f, 2f);

        // Title
        bigFont.setColor(0.95f, 0.85f, 0.4f, 1f);
        bigFont.draw(batch, "INGREDIENT SHOP", w / 2f - 160f, h - 80f);

        // Money
        font.setColor(0.4f, 1f, 0.4f, 1f);
        font.draw(batch, "Your money: $" + String.format("%.2f", CookCookCookGame.money), w / 2f - 280f, h - 120f);

        // Shopkeeper
        font.setColor(0.7f, 0.85f, 0.7f, 0.85f + 0.15f * (float)Math.sin(animTimer * 2));
        font.draw(batch, "\"" + shopKeeperMood + "\"", w / 2f - 280f, h - 145f);

        // Item list
        Array<ShopItem> visible = getVisibleItems();
        float startY = h - 190f;
        float itemHeight = 30f;

        for (int i = 0; i < visible.size; i++) {
            ShopItem item = visible.get(i);
            float itemY = startY - i * itemHeight;
            if (itemY < 100f) break;

            boolean selected = i == selectedIndex;
            boolean canAfford = CookCookCookGame.money >= item.price;

            // Selection highlight
            if (selected) {
                batch.setColor(0.3f, 0.25f, 0.1f, 0.8f);
                batch.draw(whiteTexture, w / 2f - 290f, itemY - 22f, 580f, 28f);
            }

            // Category color
            Color cat = getCategoryColor(item.category);
            font.setColor(cat.r, cat.g, cat.b, canAfford ? 1f : 0.4f);

            String stockStr = item.stock > 99 ? "∞" : String.valueOf(item.stock);
            font.draw(batch, item.name, w / 2f - 280f, itemY);
            font.draw(batch, "$" + String.format("%.2f", item.price), w / 2f + 50f, itemY);
            font.draw(batch, "Stock: " + stockStr, w / 2f + 160f, itemY);
            font.draw(batch, "[" + item.category + "]", w / 2f + 250f, itemY);
        }

        // Inventory
        font.setColor(0.8f, 0.8f, 0.5f, 1f);
        StringBuilder cartStr = new StringBuilder("Cart: ");
        for (int ci = 0; ci < inventory.size; ci++) {
            if (ci > 0) cartStr.append(", ");
            cartStr.append(inventory.get(ci));
        }
        font.draw(batch, cartStr.toString(), w / 2f - 280f, 110f);

        // Controls
        font.setColor(0.5f, 0.5f, 0.5f, 1f);
        font.draw(batch, "[UP/DOWN] Navigate  [ENTER] Buy  [ESC] Leave", w / 2f - 220f, 80f);

        batch.setColor(1f, 1f, 1f, 1f);
    }

    private Color getCategoryColor(String cat) {
        switch (cat) {
            case "Alien": return new Color(0.4f, 1f, 0.6f, 1f);
            case "Divine": return new Color(1f, 0.9f, 0.3f, 1f);
            case "Protein": return new Color(0.9f, 0.5f, 0.3f, 1f);
            case "Dairy": return new Color(0.9f, 0.9f, 0.7f, 1f);
            case "Spice": return new Color(0.9f, 0.3f, 0.2f, 1f);
            default: return new Color(0.85f, 0.85f, 0.85f, 1f);
        }
    }

    private void drawBorder(SpriteBatch batch, float x, float y, float w, float h, float t) {
        batch.draw(whiteTexture, x, y, w, t);
        batch.draw(whiteTexture, x, y + h - t, w, t);
        batch.draw(whiteTexture, x, y, t, h);
        batch.draw(whiteTexture, x + w - t, y, t, h);
    }

    public Array<String> getInventory() { return inventory; }
    public void clearInventory() { inventory.clear(); }
    public boolean isOpen() { return isOpen; }

    public void dispose() {
        if (whiteTexture != null) whiteTexture.dispose();
    }
}
