package com.cookcookcook.world;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g3d.*;
import com.badlogic.gdx.graphics.g3d.attributes.*;
import com.badlogic.gdx.graphics.g3d.loader.ObjLoader;
import com.badlogic.gdx.graphics.g3d.utils.*;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.utils.*;

public class WorldBuilder {

    private Array<Model> models = new Array<>();
    private Array<ModelInstance> instances = new Array<>();
    private ModelBuilder builder;

    private static final VertexAttributes ATTRS = new VertexAttributes(
        VertexAttribute.Position(),
        VertexAttribute.Normal(),
        VertexAttribute.TexCoords(0)
    );

    public WorldBuilder() {
        builder = new ModelBuilder();
    }

    public Array<ModelInstance> buildWorld() {
        buildGround();
        buildFoodTruck();
        buildShopAcrossStreet();
        buildStreet();
        buildNewspaperStand();
        buildSkybox();
        buildStreetProps();
        return instances;
    }

    private void addBox(float w, float h, float d, float x, float y, float z, Material mat) {
        Model m = builder.createBox(w, h, d, mat, ATTRS);
        models.add(m);
        ModelInstance inst = new ModelInstance(m);
        inst.transform.setToTranslation(x, y, z);
        instances.add(inst);
    }

    private void addCylinder(float w, float h, float d, int div, float x, float y, float z, Material mat) {
        Model m = builder.createCylinder(w, h, d, div, mat, ATTRS);
        models.add(m);
        ModelInstance inst = new ModelInstance(m);
        inst.transform.setToTranslation(x, y, z);
        instances.add(inst);
    }

    private void buildGround() {
        addBox(60f, 0.1f, 60f, 0f, -0.05f, -5f,
            new Material(ColorAttribute.createDiffuse(0.62f, 0.60f, 0.56f, 1f)));
        addBox(12f, 0.05f, 10f, 0f, 0.025f, 3f,
            new Material(ColorAttribute.createDiffuse(0.82f, 0.80f, 0.76f, 1f)));
    }

    private void buildFoodTruck() {
        Model truckModel = tryLoadModel("models/food_truck.obj");
        if (truckModel != null) {
            ModelInstance inst = new ModelInstance(truckModel);
            inst.transform.setToTranslation(-1f, 0f, 3f);
            instances.add(inst); return;
        }
        addBox(5f, 3f, 8f, 0f, 1.5f, 3f,
            new Material(ColorAttribute.createDiffuse(0.98f, 0.88f, 0.3f, 1f),
                ColorAttribute.createSpecular(0.3f, 0.3f, 0.1f, 1f)));
        addBox(5.2f, 0.3f, 8.2f, 0f, 3.15f, 3f,
            new Material(ColorAttribute.createDiffuse(0.75f, 0.62f, 0.15f, 1f)));
        addBox(2f, 1.2f, 0.1f, 0f, 1.8f, -0.55f,
            new Material(ColorAttribute.createDiffuse(0.1f, 0.08f, 0.05f, 1f)));
        for (int sx : new int[]{-1, 1}) {
            for (int sz : new int[]{-1, 1}) {
                Model wheel = builder.createCylinder(0.6f, 0.4f, 0.6f, 12,
                    new Material(ColorAttribute.createDiffuse(0.15f, 0.15f, 0.15f, 1f)), ATTRS);
                models.add(wheel);
                ModelInstance wi = new ModelInstance(wheel);
                wi.transform.setToTranslation(sx * 2.8f, 0.3f, 3f + sz * 2.5f);
                wi.transform.rotate(Vector3.Z, 90f);
                instances.add(wi);
            }
        }
        addBox(5.5f, 0.1f, 2f, 0f, 3.3f, -1.5f,
            new Material(ColorAttribute.createDiffuse(0.85f, 0.25f, 0.15f, 1f)));
        addBox(3f, 0.8f, 0.1f, 0f, 2.8f, -0.55f,
            new Material(ColorAttribute.createDiffuse(0.9f, 0.3f, 0.1f, 1f)));
    }

    private void buildShopAcrossStreet() {
        Model shopModel = tryLoadModel("models/shop.obj");
        if (shopModel != null) {
            ModelInstance inst = new ModelInstance(shopModel);
            inst.transform.setToTranslation(0f, 0f, -16f);
            instances.add(inst); return;
        }
        addBox(10f, 5f, 6f, 0f, 2.5f, -16f,
            new Material(ColorAttribute.createDiffuse(0.55f, 0.78f, 0.72f, 1f),
                ColorAttribute.createSpecular(0.2f, 0.2f, 0.2f, 1f)));
        addBox(10.3f, 0.5f, 6.3f, 0f, 5.25f, -16f,
            new Material(ColorAttribute.createDiffuse(0.3f, 0.55f, 0.5f, 1f)));
        addBox(1.5f, 2.5f, 0.1f, 0f, 1.25f, -12.95f,
            new Material(ColorAttribute.createDiffuse(0.4f, 0.28f, 0.15f, 1f)));
        for (int s : new int[]{-1, 1}) {
            addBox(2f, 1.5f, 0.1f, s * 3.2f, 2.5f, -12.95f,
                new Material(ColorAttribute.createDiffuse(0.7f, 0.85f, 0.95f, 0.7f)));
        }
        addBox(6f, 1f, 0.2f, 0f, 4.7f, -12.95f,
            new Material(ColorAttribute.createDiffuse(0.95f, 0.85f, 0.2f, 1f)));
    }

    private void buildStreet() {
        addBox(14f, 0.02f, 14f, 0f, 0.01f, -7f,
            new Material(ColorAttribute.createDiffuse(0.25f, 0.25f, 0.25f, 1f)));
        for (int i = -3; i <= 3; i++) {
            addBox(0.3f, 0.02f, 1.5f, 0f, 0.02f, -7f + i * 2.2f,
                new Material(ColorAttribute.createDiffuse(0.95f, 0.88f, 0.2f, 1f)));
        }
        for (int s : new int[]{-1, 1}) {
            addBox(14f, 0.15f, 0.3f, 0f, 0.07f, -7f + s * 7f,
                new Material(ColorAttribute.createDiffuse(0.75f, 0.73f, 0.70f, 1f)));
        }
    }

    private void buildNewspaperStand() {
        addBox(0.5f, 0.8f, 0.4f, 5f, 0.4f, 6f,
            new Material(ColorAttribute.createDiffuse(0.2f, 0.3f, 0.7f, 1f)));
        addBox(0.1f, 0.4f, 0.1f, 5f, 0.2f, 6f,
            new Material(ColorAttribute.createDiffuse(0.5f, 0.5f, 0.5f, 1f)));
    }

    private void buildSkybox() {
        Model sky = builder.createSphere(200f, 200f, 200f, 16, 16,
            new Material(ColorAttribute.createDiffuse(0.52f, 0.75f, 0.92f, 1f)), ATTRS);
        models.add(sky);
        instances.add(new ModelInstance(sky));
    }

    private void buildStreetProps() {
        float[] lampX = {-6f, 6f, -6f, 6f};
        float[] lampZ = {-5f, -5f, 1f, 1f};
        for (int i = 0; i < lampX.length; i++) {
            addCylinder(0.08f, 4f, 0.08f, 8, lampX[i], 2f, lampZ[i],
                new Material(ColorAttribute.createDiffuse(0.4f, 0.4f, 0.45f, 1f)));
            addBox(0.4f, 0.25f, 0.5f, lampX[i], 4.2f, lampZ[i],
                new Material(ColorAttribute.createDiffuse(0.9f, 0.85f, 0.5f, 1f),
                    ColorAttribute.createEmissive(0.8f, 0.7f, 0.3f, 1f)));
        }
        addCylinder(0.3f, 0.7f, 0.3f, 10, -5f, 0.35f, 5f,
            new Material(ColorAttribute.createDiffuse(0.35f, 0.35f, 0.35f, 1f)));
        for (int b = 0; b < 3; b++) {
            addBox(1.5f, 0.15f, 0.5f, -4f + b * 1.8f, 0.5f, -1.5f,
                new Material(ColorAttribute.createDiffuse(0.55f, 0.38f, 0.18f, 1f)));
            addBox(1.4f, 0.5f, 0.08f, -4f + b * 1.8f, 0.25f, -1.5f,
                new Material(ColorAttribute.createDiffuse(0.35f, 0.22f, 0.1f, 1f)));
        }
    }

    private Model tryLoadModel(String path) {
        try {
            if (Gdx.files.internal(path).exists()) {
                ObjLoader loader = new ObjLoader();
                return loader.loadModel(Gdx.files.internal(path));
            }
        } catch (Exception e) {
            Gdx.app.log("WorldBuilder", "Could not load " + path);
        }
        return null;
    }

    public void dispose() {
        for (Model m : models) m.dispose();
    }
}
