package com.cookcookcook.screens;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.math.MathUtils;
import com.cookcookcook.CookCookCookGame;

public class SplashScreen implements Screen {

    private final CookCookCookGame game;
    private SpriteBatch batch;
    private BitmapFont titleFont;
    private BitmapFont subtitleFont;
    private float timer = 0f;
    private float alpha = 0f;
    private boolean fadingIn = true;
    private int phase = 0; // 0=logo, 1=tagline, 2=ready

    // Animated steam particles
    private float[] steamX = new float[12];
    private float[] steamY = new float[12];
    private float[] steamAlpha = new float[12];
    private float[] steamSpeed = new float[12];

    public SplashScreen(CookCookCookGame game) {
        this.game = game;
    }

    @Override
    public void show() {
        batch = new SpriteBatch();
        titleFont = new BitmapFont();
        subtitleFont = new BitmapFont();
        titleFont.getData().setScale(4f);
        subtitleFont.getData().setScale(1.5f);

        // Init steam particles
        for (int i = 0; i < steamX.length; i++) {
            resetSteam(i);
            steamY[i] = MathUtils.random(200f, 500f);
        }
    }

    private void resetSteam(int i) {
        steamX[i] = MathUtils.random(400f, 880f);
        steamY[i] = 150f;
        steamAlpha[i] = MathUtils.random(0.3f, 0.8f);
        steamSpeed[i] = MathUtils.random(40f, 90f);
    }

    @Override
    public void render(float delta) {
        timer += delta;

        // Background - warm cream color
        ScreenUtils.clear(0.98f, 0.94f, 0.85f, 1f);

        // Update alpha
        if (fadingIn) {
            alpha = Math.min(1f, alpha + delta * 1.5f);
            if (alpha >= 1f) fadingIn = false;
        }

        // Update steam
        for (int i = 0; i < steamX.length; i++) {
            steamY[i] += steamSpeed[i] * delta;
            steamX[i] += MathUtils.sin(timer * 2f + i) * 20f * delta;
            steamAlpha[i] -= delta * 0.3f;
            if (steamAlpha[i] <= 0f || steamY[i] > 600f) resetSteam(i);
        }

        batch.begin();
        batch.setColor(1f, 1f, 1f, alpha);

        // Title: COOK, COOK, COOK!
        titleFont.setColor(0.18f, 0.12f, 0.05f, alpha);
        GlyphLayout layout = new GlyphLayout(titleFont, "COOK, COOK, COOK!");
        titleFont.draw(batch, "COOK, COOK, COOK!",
            (Gdx.graphics.getWidth() - layout.width) / 2f,
            Gdx.graphics.getHeight() / 2f + 80f);

        // Subtitle
        if (timer > 1.2f) {
            float subAlpha = Math.min(1f, (timer - 1.2f) * 2f);
            subtitleFont.setColor(0.55f, 0.35f, 0.1f, subAlpha * alpha);
            GlyphLayout sub = new GlyphLayout(subtitleFont, "A humble chef. An infinite hunger.");
            subtitleFont.draw(batch, "A humble chef. An infinite hunger.",
                (Gdx.graphics.getWidth() - sub.width) / 2f,
                Gdx.graphics.getHeight() / 2f - 10f);
        }

        // Press to start
        if (timer > 2.5f) {
            float pulse = 0.5f + 0.5f * MathUtils.sin(timer * 3f);
            subtitleFont.setColor(0.3f, 0.2f, 0.05f, pulse * alpha);
            GlyphLayout start = new GlyphLayout(subtitleFont, "Press ENTER to begin your destiny");
            subtitleFont.draw(batch, "Press ENTER to begin your destiny",
                (Gdx.graphics.getWidth() - start.width) / 2f,
                Gdx.graphics.getHeight() / 2f - 100f);
        }

        // Steam particles (drawn as small circles using pixel trick)
        subtitleFont.setColor(1f, 1f, 1f, 0.5f);
        for (int i = 0; i < steamX.length; i++) {
            subtitleFont.setColor(0.85f, 0.82f, 0.78f, steamAlpha[i] * alpha);
            subtitleFont.draw(batch, "~", steamX[i], steamY[i]);
        }

        // Day counter if prestige > 0
        if (CookCookCookGame.prestige > 0) {
            subtitleFont.setColor(0.7f, 0.2f, 0.2f, alpha);
            subtitleFont.draw(batch, "ASCENDED x" + CookCookCookGame.prestige, 20f, Gdx.graphics.getHeight() - 20f);
        }

        batch.end();

        // Input
        if (timer > 2.5f && Gdx.input.isKeyJustPressed(Input.Keys.ENTER)) {
            game.setScreen(new GameScreen(game));
            dispose();
        }
    }

    @Override public void resize(int w, int h) {}
    @Override public void pause() {}
    @Override public void resume() {}
    @Override public void hide() {}

    @Override
    public void dispose() {
        batch.dispose();
        titleFont.dispose();
        subtitleFont.dispose();
    }
}
