package com.cookcookcook.systems;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.math.*;
import com.cookcookcook.CookCookCookGame;

public class Newspaper {

    private String headline = "";
    private String subheadline = "";
    private String body = "";
    private String column2 = "";
    private String dateStr = "";
    private Texture whiteTexture;
    private float animTimer = 0f;

    private static final String[] EARLY_HEADLINES = {
        "Local Food Truck Opens on Main Street",
        "New Chef Impresses With Creative Menu",
        "Food Truck Draws Crowd of Curious Customers",
        "Regulars Call New Dishes 'Surprisingly Good'",
        "Chef Experiments with Unusual Combinations"
    };

    private static final String[] MID_HEADLINES = {
        "FOOD TRUCK EMPIRE EXPANDS TO 3 LOCATIONS",
        "Chef's 'New Substances' Go Viral Overnight",
        "Investors Take Notice of Mystery Cook",
        "Stock Market: BRGS Up 40% — Analysts Baffled",
        "WHO IS THE ANONYMOUS CHEF? CITY DEMANDS ANSWERS",
        "Local Shop Owner Reports 'Concerning Behavior'",
        "Scientists Confirm: New Food Compound Unclassified",
        "Chef Files Patent for 'Flavor Beyond Human Comprehension'"
    };

    private static final String[] LATE_HEADLINES = {
        "GIANT TOWER APPEARS OVERNIGHT — AUTHORITIES BAFFLED",
        "ALIEN DELEGATION VISITS LOCAL FOOD ESTABLISHMENT",
        "GODS DESCEND FOR FOOD TRUCK MEAL — EXCLUSIVE",
        "CHEF ACHIEVES MARKET DOMINION: ECONOMY RESPONDS",
        "MISSING PERSONS REPORTS NEAR RESTAURANT DISTRICT",
        "THE CHEF CANNOT BE STOPPED, SAY ECONOMISTS",
        "DIVINE SUBSTANCES CONFIRMED: CHURCH WEIGHS IN",
        "CHEF'S NAME SPOKEN IN 14 STAR SYSTEMS"
    };

    private static final String[] ASCENSION_HEADLINES = {
        "THE CHEF HAS ASCENDED. WE ARE ALL WITNESSES.",
        "REALITY RESTRUCTURED AROUND A SINGLE KITCHEN",
        "THEY FEED ON YOUR CREATIONS ACROSS ALL WORLDS",
        "IT IS DONE. AND IT BEGINS AGAIN.",
        "THE CREATOR OF FOOD. THERE IS NOTHING ELSE."
    };

    private static final String[] BODY_TEXTS = {
        "Witnesses describe the smell as 'indescribable but irresistible.'",
        "The chef declined to comment. The chef never comments.",
        "Experts are divided. The food is not.",
        "No recipe book exists. No recipe book will ever exist.",
        "The queue stretches three blocks. No one is leaving.",
        "The shopkeeper across the street was unavailable for comment.",
        "Officials have issued no statement. Officials have no words.",
        "Those who tasted it have not been the same since.",
        "The stock market moved. The chef smiled.",
        "Workers at the location have not been seen outside in days."
    };

    private static final String[] COLUMNS = {
        "STOCKS: COOK sector up 800% this quarter.",
        "WEATHER: Warm. Smells like something cooking.",
        "SPORTS: Cancelled. Everyone went to the food truck.",
        "POLITICS: The chef has not run for office. Yet.",
        "SCIENCE: New molecule discovered in 'The Dish'.",
        "OPINION: I tried it. I cannot explain what I felt.",
        "FOREIGN: Other nations want the recipe. None will get it.",
        "CRIME: None reported. Too busy eating."
    };

    public Newspaper() {
        Pixmap p = new Pixmap(1, 1, Pixmap.Format.RGBA8888);
        p.setColor(Color.WHITE);
        p.fill();
        whiteTexture = new Texture(p);
        p.dispose();
    }

    public void generateHeadline() {
        float greed = CookCookCookGame.greedLevel;
        int prestige = CookCookCookGame.prestige;

        String[] pool;
        if (prestige >= 2 || greed >= 90f) {
            pool = ASCENSION_HEADLINES;
        } else if (greed >= 50f) {
            pool = LATE_HEADLINES;
        } else if (greed >= 20f) {
            pool = MID_HEADLINES;
        } else {
            pool = EARLY_HEADLINES;
        }

        headline = pool[MathUtils.random(pool.length - 1)];
        subheadline = BODY_TEXTS[MathUtils.random(BODY_TEXTS.length - 1)];
        body = BODY_TEXTS[MathUtils.random(BODY_TEXTS.length - 1)];
        column2 = COLUMNS[MathUtils.random(COLUMNS.length - 1)];
        dateStr = "Day " + CookCookCookGame.day + " — Cook City Gazette";
    }

    public void updateReputation() {
        // Called at end of each day
    }

    public void renderUI(SpriteBatch batch, BitmapFont font, BitmapFont bigFont) {
        int w = Gdx.graphics.getWidth();
        int h = Gdx.graphics.getHeight();
        animTimer += Gdx.graphics.getDeltaTime();

        // Newspaper background - cream/off-white
        batch.setColor(0.96f, 0.93f, 0.85f, 0.97f);
        batch.draw(whiteTexture, w / 2f - 340f, h / 2f - 250f, 680f, 500f);

        // Border
        batch.setColor(0.2f, 0.18f, 0.12f, 1f);
        drawBorder(batch, w / 2f - 340f, h / 2f - 250f, 680f, 500f, 3f);

        // Header bar
        batch.setColor(0.15f, 0.13f, 0.08f, 1f);
        batch.draw(whiteTexture, w / 2f - 340f, h / 2f + 210f, 680f, 40f);

        // Newspaper title
        bigFont.setColor(0.96f, 0.93f, 0.85f, 1f);
        bigFont.getData().setScale(1.8f);
        GlyphLayout gl = new GlyphLayout(bigFont, "COOK CITY GAZETTE");
        bigFont.draw(batch, "COOK CITY GAZETTE", w / 2f - gl.width / 2f, h / 2f + 243f);
        bigFont.getData().setScale(2f);

        // Date
        font.setColor(0.3f, 0.28f, 0.2f, 1f);
        font.draw(batch, dateStr, w / 2f - 200f, h / 2f + 208f);

        // Separator line
        batch.setColor(0.3f, 0.25f, 0.15f, 1f);
        batch.draw(whiteTexture, w / 2f - 330f, h / 2f + 185f, 660f, 2f);

        // HEADLINE
        bigFont.setColor(0.08f, 0.06f, 0.03f, 1f);
        bigFont.getData().setScale(1.3f);
        float headlineX = w / 2f - 320f;
        float headlineY = h / 2f + 175f;
        wrapText(batch, bigFont, headline, headlineX, headlineY, 640f, 25f);
        bigFont.getData().setScale(2f);

        // Separator
        batch.setColor(0.3f, 0.25f, 0.15f, 1f);
        batch.draw(whiteTexture, w / 2f - 320f, h / 2f + 115f, 640f, 1f);

        // Subheadline
        font.setColor(0.3f, 0.25f, 0.15f, 1f);
        font.getData().setScale(1.15f);
        font.draw(batch, subheadline, headlineX, h / 2f + 108f);
        font.getData().setScale(1.2f);

        // Divider for columns
        batch.setColor(0.3f, 0.25f, 0.15f, 0.5f);
        batch.draw(whiteTexture, w / 2f - 10f, h / 2f - 230f, 1f, 300f);

        // Column 1 body
        font.setColor(0.15f, 0.12f, 0.08f, 1f);
        font.getData().setScale(1.0f);
        wrapTextSmall(batch, font, body, headlineX, h / 2f + 75f, 310f, 18f);

        // Column 2
        font.setColor(0.2f, 0.18f, 0.12f, 1f);
        wrapTextSmall(batch, font, column2, w / 2f + 10f, h / 2f + 75f, 310f, 18f);

        // Footer
        font.setColor(0.4f, 0.35f, 0.25f, 0.7f);
        font.draw(batch, "Prestige: " + CookCookCookGame.prestige + "  |  Customers Served: " + CookCookCookGame.totalCustomersServed,
            headlineX, h / 2f - 225f);

        font.setColor(0.5f, 0.45f, 0.35f, 0.9f);
        font.draw(batch, "[ESC] Close newspaper", headlineX, h / 2f - 245f);

        font.getData().setScale(1.2f);
        batch.setColor(1f, 1f, 1f, 1f);
    }

    private void wrapText(SpriteBatch batch, BitmapFont font, String text, float x, float y, float maxW, float lineH) {
        String[] words = text.split(" ");
        StringBuilder line = new StringBuilder();
        float curY = y;
        for (String word : words) {
            String test = line + (line.length() > 0 ? " " : "") + word;
            GlyphLayout gl = new GlyphLayout(font, test);
            if (gl.width > maxW && line.length() > 0) {
                font.draw(batch, line.toString(), x, curY);
                curY -= lineH;
                line = new StringBuilder(word);
            } else {
                if (line.length() > 0) line.append(" ");
                line.append(word);
            }
        }
        if (line.length() > 0) font.draw(batch, line.toString(), x, curY);
    }

    private void wrapTextSmall(SpriteBatch batch, BitmapFont font, String text, float x, float y, float maxW, float lineH) {
        wrapText(batch, font, text, x, y, maxW, lineH);
    }

    private void drawBorder(SpriteBatch b, float x, float y, float w, float h, float t) {
        b.draw(whiteTexture, x, y, w, t);
        b.draw(whiteTexture, x, y + h - t, w, t);
        b.draw(whiteTexture, x, y, t, h);
        b.draw(whiteTexture, x + w - t, y, t, h);
    }

    public void dispose() {
        if (whiteTexture != null) whiteTexture.dispose();
    }
}
