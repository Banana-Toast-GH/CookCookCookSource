package com.cookcookcook.systems;

import com.badlogic.gdx.graphics.g3d.*;
import com.badlogic.gdx.graphics.VertexAttribute;
import com.badlogic.gdx.graphics.VertexAttributes;
import com.badlogic.gdx.graphics.g3d.attributes.*;
import com.badlogic.gdx.graphics.g3d.utils.*;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.utils.*;
import com.cookcookcook.CookCookCookGame;

public class CustomerSystem {

    public static class Customer {
        public String name;
        public String order;
        public float patience;       // seconds until they leave
        public float maxPatience;
        public float payment;
        public boolean waiting;
        public Vector3 position;
        public ModelInstance modelInst;
        public boolean isAlien;
        public boolean isGod;

        public Customer(String name, String order, float payment, float patience) {
            this.name = name;
            this.order = order;
            this.payment = payment;
            this.patience = patience;
            this.maxPatience = patience;
            this.waiting = true;
            this.position = new Vector3();
        }
    }

    private Array<Customer> queue = new Array<>();
    private ModelBuilder modelBuilder = new ModelBuilder();
    private Array<Model> customerModels = new Array<>();

    private float spawnTimer = 0f;
    private float spawnInterval = 12f;
    private int maxQueue = 5;

    private static final String[] HUMAN_NAMES = {
        "Bob", "Alice", "Dave", "Maya", "Carlos", "Jin", "Priya", "Tom"
    };
    private static final String[] ALIEN_NAMES = {
        "Zx'var", "Klorg", "Nebulox", "Yemthu", "Qrix"
    };
    private static final String[] GOD_NAMES = {
        "The Eternal", "He Who Hungers", "Vessel of Taste", "The Devourer"
    };

    private static final String[] ORDERS = {
        "Just... something good.", "Surprise me.", "The usual.",
        "Something I've never tasted.", "Make it fast.", "Cook it with love.",
        "I want to ascend through flavor.", "Give me the NEW substance.",
        "I heard you invented something. I need it.", "...just feed me."
    };

    private float[] customerColors = {
        0.9f, 0.75f, 0.6f,   // skin tone 1
        0.7f, 0.55f, 0.4f,   // skin tone 2
        0.4f, 0.35f, 0.3f,   // skin tone 3
        0.55f, 0.85f, 0.55f, // alien green
        0.8f, 0.6f, 1.0f,    // alien purple
        1.0f, 0.9f, 0.3f,    // god gold
    };

    public CustomerSystem() {}

    public void update(float delta) {
        spawnTimer += delta;

        // Spawn new customers
        if (spawnTimer >= spawnInterval && queue.size < maxQueue) {
            spawnCustomer();
            spawnTimer = 0f;

            // Increase spawn rate as greed grows
            spawnInterval = Math.max(4f, 12f - CookCookCookGame.greedLevel * 0.06f);
        }

        // Update patience
        Array<Customer> toRemove = new Array<>();
        for (Customer c : queue) {
            if (c.waiting) {
                c.patience -= delta;
                if (c.patience <= 0f) {
                    toRemove.add(c);
                }
            }
        }
        for (Customer c : toRemove) {
            queue.removeValue(c, true);
        }
    }

    private void spawnCustomer() {
        float greed = CookCookCookGame.greedLevel;
        boolean isAlien = greed > 40f && MathUtils.random() < 0.3f;
        boolean isGod = greed > 75f && MathUtils.random() < 0.15f;

        String name;
        float payment;
        float patience;

        if (isGod) {
            name = GOD_NAMES[MathUtils.random(GOD_NAMES.length - 1)];
            payment = MathUtils.random(80f, 200f);
            patience = 60f;
        } else if (isAlien) {
            name = ALIEN_NAMES[MathUtils.random(ALIEN_NAMES.length - 1)];
            payment = MathUtils.random(20f, 60f);
            patience = 40f;
        } else {
            name = HUMAN_NAMES[MathUtils.random(HUMAN_NAMES.length - 1)];
            payment = MathUtils.random(5f, 20f);
            patience = 30f;
        }

        // Apply prestige bonuses
        if (containsPower("THE TONGUE OF GODS")) payment *= 3f;

        String order = ORDERS[MathUtils.random(ORDERS.length - 1)];
        Customer c = new Customer(name, order, payment, patience);
        c.isAlien = isAlien;
        c.isGod = isGod;

        // Spawn position in queue line
        int idx = queue.size;
        c.position.set(-1f + idx * 1.2f, 0f, -0.8f);

        // Create 3D model for customer
        float[] col = getCustomerColor(isGod, isAlien);
        Model body = modelBuilder.createCapsule(0.25f, 1.6f, 8,
            new Material(ColorAttribute.createDiffuse(col[0], col[1], col[2], 1f)),
            
            VertexAttribute.Position(),
            |
            com.badlogic.gdx.graphics.VertexAttribute.Normal() |
            com.badlogic.gdx.graphics.VertexAttribute.TexCoords(0)
        );
        customerModels.add(body);
        c.modelInst = new ModelInstance(body);
        c.modelInst.transform.setToTranslation(c.position);

        queue.add(c);
    }

    private float[] getCustomerColor(boolean isGod, boolean isAlien) {
        if (isGod) return new float[]{1.0f, 0.9f, 0.3f};
        if (isAlien) {
            return MathUtils.random() < 0.5f
                ? new float[]{0.4f, 0.85f, 0.55f}
                : new float[]{0.8f, 0.6f, 1.0f};
        }
        // Random human skin
        int skin = MathUtils.random(2);
        float[][] skins = {
            {0.9f, 0.75f, 0.6f},
            {0.7f, 0.55f, 0.4f},
            {0.4f, 0.35f, 0.3f}
        };
        return skins[skin];
    }

    public void render(ModelBatch batch, com.badlogic.gdx.graphics.g3d.Environment env) {
        for (Customer c : queue) {
            if (c.modelInst != null) {
                batch.render(c.modelInst, env);
            }
        }
    }

    public boolean hasWaitingCustomer() {
        return queue.size > 0;
    }

    public Customer getCurrentCustomer() {
        return queue.size > 0 ? queue.first() : null;
    }

    public float serveCurrentCustomer(String foodName) {
        if (queue.size == 0) return 0f;
        Customer c = queue.removeIndex(0);

        // Calculate tip based on how long they waited vs patience
        float patienceRatio = c.patience / c.maxPatience;
        float tip = c.payment * (0.5f + patienceRatio * 0.5f);

        // Reposition remaining customers
        for (int i = 0; i < queue.size; i++) {
            queue.get(i).position.set(-1f + i * 1.2f, 0f, -0.8f);
            if (queue.get(i).modelInst != null) {
                queue.get(i).modelInst.transform.setToTranslation(queue.get(i).position);
            }
        }

        return tip;
    }

    public Array<Customer> getQueue() { return queue; }

    public void reset() {
        queue.clear();
        spawnTimer = 0f;
    }

    private boolean containsPower(String power) {
        for (String p : CookCookCookGame.prestigePowers) {
            if (power.equals(p)) return true;
        }
        return false;
    }

    public void dispose() {
        for (Model m : customerModels) m.dispose();
    }
}
