# COOK, COOK, COOK!
### *A humble chef. An infinite hunger.*

---

## QUICK START

1. Extract this ZIP anywhere on your PC
2. Run `install.bat` as Administrator (right-click → Run as Admin)
3. Wait for the build (first time downloads ~50MB of LibGDX libraries)
4. Play

If you already have Java 11+ and Gradle installed, the build takes about 30 seconds.

---

## CONTROLS

| Key | Action |
|-----|--------|
| WASD | Move |
| Right-Click + Drag | Look around |
| E | Interact with objects |
| SPACE | Minigame action (chop / lower heat) |
| UP/DOWN | Navigate menus |
| ENTER / E | Confirm / Buy |
| B | Buy stock |
| S | Sell stock |
| ESC | Close menus |

---

## GAMEPLAY LOOP

```
Buy ingredients (shop across street)
         ↓
Cook them (cooking station in truck)
    ↓ Knife minigame (SPACE on green)
    ↓ Boil minigame (hold SPACE to control heat)
         ↓
Serve customers [E] at window
         ↓
Earn money → invest in stocks → buy rarer ingredients
         ↓
Greed fills. Check newspaper. See your name.
         ↓
100% Greed → ASCENSION → White void → Choose power → Begin again
```

---

## THE COOKING MINIGAMES

### Knife (Chopping)
- A bar moves back and forth
- Press SPACE when the indicator is in the **green zone**
- Hit required number of times to proceed
- Green zone **shrinks** as your greed grows

### Boil (Temperature Control)
- A vertical bar shows current heat
- Heat naturally rises over time
- Hold SPACE to lower the temperature
- Keep heat **in the green zone** for 8 seconds to complete
- **Burn it on purpose** for a chance to invent a new substance

---

## PROGRESSION

| Greed Level | What Changes |
|-------------|--------------|
| 0-20% | Normal customers, basic items in shop |
| 20-40% | More customers, newspaper mentions you |
| 40-60% | Alien ingredients unlock, alien customers appear |
| 60-85% | God-tier customers, divine ingredients, tower permit issued |
| 85-100% | ASCENSION WARNING flashes |
| 100% | ASCENSION — white void — choose 1 of 6 powers |

---

## THE 6 ASCENSION POWERS

When you ascend, stand in the white void and click a pedestal:

1. **THE TONGUE OF GODS** — Customers pay 3x more
2. **INFINITE YIELD** — Shop stock never runs out
3. **MARKET DOMINION** — Stocks always trend upward for you
4. **STAFF BINDING** — Employees work faster (unlocks at Day 10+)
5. **COSMIC RECIPE** — Alien and god combo recipes become available
6. **GREED MADE FLESH** — Greed fills 2x faster (ascend sooner each run)

---

## ADDING 3D MODELS (IMPORTANT FOR BEST VISUALS)

The game uses **fallback colored geometry** by default. Replace with real models for the full visual experience:

### Free Model Sources

**Food Truck:**
- https://opengameart.org — search "food truck"
- https://kenney.nl/assets — City Kit, Vehicles
- https://sketchfab.com/search?q=food+truck&features=downloadable&sort_by=-likeCount

**Shop / Building:**
- https://kenney.nl/assets/city-kit-commercial
- https://opengameart.org/content/free-lowpoly-city

**Ingredients / Food:**
- https://kenney.nl/assets/food-kit
- https://opengameart.org — search "food 3d"

**Characters (customers):**
- https://kenney.nl/assets/character-pack
- https://opengameart.org/content/lowpoly-characters

### How to install models

1. Export model as `.obj` with `.mtl` texture file
2. Place in `assets/models/` folder:
   - `assets/models/food_truck.obj`
   - `assets/models/shop.obj`
   - `assets/models/customer_human.obj`
   - `assets/models/customer_alien.obj`
3. Place textures in `assets/textures/`
4. Rebuild: `gradlew desktop:jar`

The game automatically loads these files if they exist. If not, it uses the fallback geometry.

### For better rendering (optional)
Convert OBJ to LibGDX's native format for faster loading:
```
gdx-converter model.obj model.g3db
```

---

## PROJECT STRUCTURE

```
CookCookCook/
├── core/                          ← Game logic (platform-independent)
│   └── src/main/java/com/cookcookcook/
│       ├── CookCookCookGame.java  ← Main game class
│       ├── screens/               ← SplashScreen, GameScreen, AscensionScreen
│       ├── systems/               ← CookingStation, CustomerSystem, ShopSystem, StockBoard, Newspaper
│       ├── ui/                    ← HUD
│       └── world/                 ← WorldBuilder (3D scene)
├── desktop/                       ← Desktop launcher (LWJGL3)
├── assets/                        ← Models, textures, fonts, sounds
│   ├── models/                    ← DROP YOUR .obj FILES HERE
│   └── textures/                  ← DROP YOUR TEXTURES HERE
├── build.gradle                   ← Root build file
├── settings.gradle
├── install.bat                    ← THE INSTALLER — run this first
└── README.md
```

---

## BUILDING MANUALLY

If you want to build without the installer:

```bash
# Windows
gradlew.bat desktop:jar

# Linux/Mac
./gradlew desktop:jar

# Output:
desktop/build/libs/CookCookCook.jar
```

Run the game:
```bash
java -jar desktop/build/libs/CookCookCook.jar
```

---

## REQUIREMENTS

- Windows 10/11 (installer auto-installs dependencies)
- Java 11 or higher (installer handles this)
- Gradle 7+ (installer handles this)
- ~200MB disk space
- OpenGL 3.0+ capable GPU (any GPU from 2010+)

---

## LORE

You are a chef.

You have a food truck.

You have $50.

The shop is across the street.

You will not stop.

You will not follow a recipe.

You will smash ingredients together and create new substances.

You will hire workers. They will not leave.

You will build a tower.

You will serve aliens.

You will serve gods.

You will see your name in the newspaper.

You will ascend.

And then you will do it again.

Because the hunger doesn't stop.

Because they will eat everything you make.

Because you were never just a chef.

**You are the Creator.**

---

*Cook, Cook, Cook! — a game about food, greed, and becoming something that cannot be named.*
